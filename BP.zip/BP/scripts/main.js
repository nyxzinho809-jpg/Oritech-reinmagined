import { world, system, ItemStack, GameMode, ItemLockMode } from "@minecraft/server";
import * as RX from "./reactor.js";

// layout dos multiblocos igual ao Java: cores = offsets relativos ao controlador (frame do Java); ex/ey/ez = deslocamento do modelo (px)
const MACHINES = {"large_storage":{"cores":[[0,1,0],[1,0,0],[1,1,0]],"deploy":0,"door":false,"skin":0,"ny":2,"ex":0,"ez":0,"ey":0},"fuel_generator":{"cores":[[0,0,1],[0,0,-1],[-1,0,1],[-1,0,0],[-1,0,-1],[-2,0,1],[-2,0,0],[-2,0,-1],[0,1,1],[0,1,0],[0,1,-1],[-1,1,1],[-1,1,0],[-1,1,-1],[-2,1,1],[-2,1,0],[-2,1,-1]],"deploy":93,"door":false,"skin":0,"ny":2,"ex":-0.0,"ez":-16.0,"ey":-0.0},"basic_generator":{"cores":[],"deploy":0,"door":false,"skin":0,"ny":1,"ex":-2.0,"ez":-0.0,"ey":0},"bio_generator":{"cores":[[0,1,0]],"deploy":83,"door":false,"skin":0,"ny":2,"ex":-0.0,"ez":-0.0,"ey":0},"lava_generator":{"cores":[[0,1,0]],"deploy":88,"door":false,"skin":0,"ny":2,"ex":-0.0,"ez":0.01,"ey":0},"steam_engine":{"cores":[[0,1,0],[0,0,-1],[0,1,-1]],"deploy":84,"door":false,"skin":0,"ny":2,"ex":8.013,"ez":-0.0,"ey":0},"big_solar_panel":{"cores":[[1,1,1],[0,1,1],[-1,1,1],[1,1,0],[0,1,0],[-1,1,0],[1,1,-1],[0,1,-1],[-1,1,-1],[1,0,1],[0,0,1],[-1,0,1],[1,0,-1],[0,0,-1],[-1,0,-1]],"deploy":113,"door":false,"skin":0,"ny":2,"ex":0.005,"ez":-0.0,"ey":0},"unstable_container":{"cores":[[-1,-2,-1],[0,-2,-1],[1,-2,-1],[-1,-2,0],[0,-2,0],[1,-2,0],[-1,-2,1],[0,-2,1],[1,-2,1],[-1,-1,-1],[0,-1,-1],[1,-1,-1],[-1,-1,0],[0,-1,0],[1,-1,0],[-1,-1,1],[0,-1,1],[1,-1,1],[-1,0,-1],[0,0,-1],[1,0,-1],[-1,0,0],[1,0,0],[-1,0,1],[0,0,1],[1,0,1],[0,1,-1],[-1,1,0],[0,1,0],[1,1,0],[0,1,1]],"deploy":143,"door":false,"skin":0,"ny":2,"ex":4.718,"ez":-3.0,"ey":-0.0},"powered_furnace":{"cores":[[0,1,0]],"deploy":29,"door":false,"skin":0,"ny":2,"ex":-0.0,"ez":-0.0,"ey":0},"pulverizer":{"cores":[],"deploy":0,"door":false,"skin":0,"ny":1,"ex":-0.0,"ez":-0.0,"ey":0},"foundry":{"cores":[[0,0,1],[0,1,0],[0,1,1]],"deploy":98,"door":false,"skin":0,"ny":2,"ex":-8.0,"ez":-0.875,"ey":-0.0},"centrifuge":{"cores":[[0,1,0]],"deploy":125,"door":false,"skin":0,"ny":2,"ex":-0.0,"ez":-0.0,"ey":0},"assembler":{"cores":[[0,0,1],[0,1,0],[0,1,1]],"deploy":97,"door":false,"skin":0,"ny":2,"ex":-6.724,"ez":-0.0,"ey":-0.0},"fragment_forge":{"cores":[[0,1,0],[0,0,1],[0,1,1],[1,0,1],[1,1,1],[1,0,0],[1,1,0]],"deploy":128,"door":false,"skin":0,"ny":2,"ex":-7.878,"ez":8.0,"ey":0},"atomic_forge":{"cores":[[1,0,1],[1,0,0],[1,0,-1],[0,0,1],[0,0,-1],[-1,0,1],[-1,0,0],[-1,0,-1]],"deploy":113,"door":false,"skin":0,"ny":1,"ex":-2.05,"ez":-0.0,"ey":-0.0},"cooler":{"cores":[[0,0,-1]],"deploy":108,"door":false,"skin":0,"ny":1,"ex":8.0,"ez":-0.013,"ey":-0.0},"pump":{"cores":[],"deploy":0,"door":false,"skin":0,"ny":1,"ex":0.5,"ez":-0.25,"ey":-0.0},"refinery":{"cores":[[0,1,0],[0,0,-1],[0,1,-1],[1,0,-1],[1,1,-1],[1,0,0],[1,1,0],[2,0,-1],[2,1,-1]],"deploy":93,"door":false,"skin":0,"ny":2,"ex":5.05,"ez":16.0,"ey":0},"tainted_refinery":{"cores":[[0,1,0],[0,0,-1],[0,1,-1],[1,0,-1],[1,1,-1],[1,0,0],[1,1,0],[2,0,-1],[2,1,-1]],"deploy":93,"door":false,"skin":0,"ny":2,"ex":5.5,"ez":16.0,"ey":-0.0},"treefeller":{"cores":[],"deploy":0,"door":false,"skin":0,"ny":1,"ex":-4.5,"ez":1.963,"ey":0},"deep_drill":{"cores":[[0,0,1],[0,0,-1],[-1,0,1],[-1,0,0],[-1,0,-1],[-2,0,1],[-2,0,0],[-2,0,-1],[0,1,1],[0,1,0],[0,1,-1],[-1,1,1],[-1,1,0],[-1,1,-1],[-2,1,1],[-2,1,0],[-2,1,-1],[0,2,1],[0,2,0],[0,2,-1],[-1,2,1],[-1,2,0],[-1,2,-1],[-2,2,1],[-2,2,0],[-2,2,-1]],"deploy":384,"door":false,"skin":0,"ny":3,"ex":0.0,"ez":-16.0,"ey":0},"small_storage":{"cores":[],"deploy":0,"door":false,"skin":0,"ny":1,"ex":0.0,"ez":0.0,"ey":0.0},"creative_storage":{"cores":[],"deploy":0,"door":false,"skin":0,"ny":1,"ex":0.0,"ez":0.0,"ey":0.0},"enchanter":{"cores":[],"deploy":0,"door":false,"skin":0,"ny":1,"ex":-0.237,"ez":-1.025,"ey":0},"enchantment_catalyst":{"cores":[],"deploy":0,"door":false,"skin":0,"ny":1,"ex":0.5,"ez":0.5,"ey":0},"augment_application":{"cores":[[0,0,1],[0,0,-1],[-1,0,0],[-1,0,1],[-1,0,-1],[0,1,1],[0,1,-1],[-1,1,0],[-1,1,1],[-1,1,-1]],"deploy":131,"door":false,"skin":0,"ny":2,"ex":0.0,"ez":-8.0,"ey":0},"laser_arm":{"cores":[[1,0,0]],"deploy":91,"door":false,"skin":0,"ny":1,"ex":-0.0,"ez":-0.0,"ey":0},"pipe_booster":{"cores":[],"deploy":0,"door":false,"skin":0,"ny":1,"ex":-0.0,"ez":5.588,"ey":-0.0},"drone_port":{"cores":[[0,0,1],[0,0,-1],[-1,0,1],[-1,0,0],[-1,0,-1],[-2,0,1],[-2,0,0],[-2,0,-1],[0,1,0],[0,1,1],[-1,1,-1]],"deploy":138,"door":false,"skin":0,"ny":2,"ex":0.0,"ez":-16.0,"ey":0},"refinery_module":{"cores":[[0,0,-1],[1,0,-1],[1,0,0],[2,0,-1],[2,0,0]],"deploy":48,"door":false,"skin":0,"ny":1,"ex":4.95,"ez":12.975,"ey":0},"tech_door":{"cores":[[0,1,0],[0,2,0]],"deploy":0,"door":true,"skin":0,"ny":3,"ex":0,"ez":0,"ey":0},"hangar_door":{"cores":[[0,1,0],[0,2,0]],"deploy":60,"door":true,"skin":0,"ny":3,"ex":0,"ez":0,"ey":0},"accelerator_controller":{"cores":[],"deploy":0,"door":false,"skin":0,"ny":1,"ex":0,"ey":0,"ez":0},"accelerator_motor":{"cores":[],"deploy":0,"door":false,"skin":0,"ny":1,"ex":0,"ey":0,"ez":0},"accelerator_sensor":{"cores":[],"deploy":0,"door":false,"skin":0,"ny":1,"ex":0,"ey":0,"ez":0}};
const NAMES = {"large_storage":"Armazenamento de Energia Grande","fuel_generator":"Gerador a Combustível","basic_generator":"Gerador Básico","bio_generator":"Biogerador","lava_generator":"Gerador de Lava","steam_engine":"Motor a Vapor","big_solar_panel":"Painel Solar Grande","unstable_container":"Reator Instável","powered_furnace":"Fornalha Elétrica","pulverizer":"Pulverizador","foundry":"Fundição","centrifuge":"Centrífuga","assembler":"Montadora","fragment_forge":"Forja de Fragmentos","atomic_forge":"Forja Atômica","cooler":"Resfriador Industrial","pump":"Bomba","refinery":"Refinaria","tainted_refinery":"Refinaria Corrompida","treefeller":"Cortador de Árvores","deep_drill":"Extrator de Bedrock","small_storage":"Banco de Energia","creative_storage":"Fonte de Energia Criativa","enchanter":"Encantador","enchantment_catalyst":"Catalisador Arcano","augment_application":"Estação de Melhoria","laser_arm":"Torre Laser","pipe_booster":"Impulsionador","drone_port":"Porto de Drones","refinery_module":"Módulo de Refinaria","tech_door":"Porta Tecnológica","hangar_door":"Porta de Hangar","accelerator_controller":"Controlador do Acelerador","accelerator_motor":"Motor do Acelerador","accelerator_sensor":"Sensor do Acelerador"};

const PART = "oritech:machine_part", DOOR_PART = "oritech:door_part", GHOST = "oritech:ghost_block";
const isPartId = (t) => t === PART || t === DOOR_PART;
const STEP = 10;                 // ticks entre atualizações
const FLOW = 20000;              // RF máximos por rede por atualização (cabo comum)
const FACE = { south: 0, west: 1, north: 2, east: 3 };
const FLIP_FRONT = false;        // true = inverte a frente da máquina
// ajuste fino (se o modelo não bater com os blocos fantasmas): /scriptevent oritech:foot 0|1|2|3
const footRot = () => (world.getDynamicProperty("oritech:foot") ?? 0) % 4;
// se o painel solar inclinar para o lado contrário do sol: /scriptevent oritech:solar_flip
const solarSign = () => (world.getDynamicProperty("oritech:solar_flip") ? -1 : 1);
// eixo do painel solar: 0..3 = giro da entidade (o certo é a inclinação ficar leste-oeste); vale também para painéis já montados
const solarYaw = () => (world.getDynamicProperty("oritech:solar_yaw") ?? 0) % 4;
system.afterEvents.scriptEventReceive.subscribe((ev) => {
  const say = (t) => { try { ev.sourceEntity?.sendMessage(t); } catch {} };
  if (ev.id === "oritech:foot") {
    const v = parseInt(ev.message);
    if (v >= 0 && v <= 3) { world.setDynamicProperty("oritech:foot", v); say(`§bOritech: rotação do layout = ${v} (vale para novos projetos)`); }
    else say("§cUse /scriptevent oritech:foot 0, 1, 2 ou 3");
  } else if (ev.id === "oritech:solar_yaw") {
    const v = parseInt(ev.message);
    if (v >= 0 && v <= 3) { world.setDynamicProperty("oritech:solar_yaw", v); say(`§bOritech: giro do painel solar = ${v} (aplica em todos os painéis)`); }
    else say("§cUse /scriptevent oritech:solar_yaw 0, 1, 2 ou 3");
  } else if (ev.id === "oritech:ctm") {
    const a = (ev.message ?? "").trim().toLowerCase(); let fl = String(world.getDynamicProperty("oritech:ctm") ?? "");
    if (a === "reset") fl = ""; else if (["x", "y", "z"].includes(a)) fl = fl.includes(a) ? fl.replace(a, "") : fl + a; else { say("§cUse /scriptevent oritech:ctm x, y, z ou reset"); return; }
    world.setDynamicProperty("oritech:ctm", fl);
    const src = ev.sourceEntity ?? world.getAllPlayers()[0];
    if (src) ctmRefreshNear(src.dimension, src.location);
    say(`§bOritech: eixos invertidos nas paredes do reator = ${fl || "nenhum"} (atualizando as paredes num raio de 20 blocos)`);
  } else if (ev.id === "oritech:solar_flip") {
    const on = world.getDynamicProperty("oritech:solar_flip") ? 0 : 1;
    world.setDynamicProperty("oritech:solar_flip", on); say(`§bOritech: painel solar ${on ? "invertido" : "normal"}`);
  }
});
const COLORS = ["orange", "camo", "diamond", "fluxite", "industrial", "netherite", "redstone", "sculk", "white"];
const coreColor = (t) => (t.startsWith("oritech:machine_core_") ? t.slice(21) : null);
const PAINTS = Object.fromEntries(COLORS.map((c, i) => [`oritech:${c}_paint`, i]));

const PIPE_FAM = { "oritech:energy_cable": "energy", "oritech:superconductor_cable": "energy", "oritech:energy_duct": "energy", "oritech:superconductor_duct": "energy",
  "oritech:item_pipe": "item", "oritech:transparent_item_pipe": "item", "oritech:item_duct": "item", "oritech:fluid_pipe": "fluid", "oritech:fluid_duct": "fluid" };
const DUCT = new Set(["oritech:energy_duct", "oritech:superconductor_duct", "oritech:item_duct", "oritech:fluid_duct"]);
const SUPER = new Set(["oritech:superconductor_cable", "oritech:superconductor_duct"]);

// ---------------- geradores ----------------
const mc = (a) => a.map((x) => "minecraft:" + x);
const fuelMap = (names, ticks) => Object.fromEntries(mc(names).map((n) => [n, ticks]));
const BIO = "oritech:solid_biofuel";
const COALS = { ...fuelMap(["coal", "charcoal"], 1600), "minecraft:coal_block": 16000, "minecraft:blaze_rod": 2400, [BIO]: 3200 };
const GEN = {
  basic_generator: { rf: 12, cap: 20000, fuels: { ...COALS, "minecraft:stick": 100,
      ...fuelMap(["oak_planks", "spruce_planks", "birch_planks", "jungle_planks", "acacia_planks", "dark_oak_planks"], 300) } },
  fuel_generator: { rf: 40, cap: 100000, fuels: { ...COALS } },
  bio_generator: { rf: 18, cap: 40000, fuels: { ...fuelMap(["wheat", "wheat_seeds", "beetroot", "carrot", "potato", "apple", "sweet_berries", "melon_slice", "sugar_cane", "kelp"], 400),
      ...fuelMap(["rotten_flesh", "spider_eye", "bread", "pumpkin"], 800), "minecraft:hay_block": 3600, [BIO]: 3200 } },
  lava_generator: { rf: 60, cap: 100000, fuels: { "minecraft:lava_bucket": 20000 }, returns: "minecraft:bucket" },
  steam_engine: { rf: 50, cap: 60000, fuels: { ...COALS }, water: { "minecraft:water_bucket": 4000 }, returns: "minecraft:bucket" },
  big_solar_panel: { rf: 16, cap: 50000, solar: true, fuels: {} },
  unstable_container: { rf: 300, cap: 500000, fuels: { "oritech:uranium_pellet": 12000 }, water: { "minecraft:water_bucket": 6000 }, returns: "minecraft:bucket" },
};
// o reator nuclear usa o mesmo armazenamento/rede de energia dos geradores (a lógica própria fica em reactor.js)
GEN.nuclear_reactor = { rf: 0, cap: RX.CFG.MAX_ENERGY, fuels: {} };
NAMES.nuclear_reactor = "Reator Nuclear";
// bancos de energia e utilitários especiais
const STORE = { large_storage: { cap: 20000000, io: 10000 }, small_storage: { cap: 2000000 }, creative_storage: { cap: 1000000000, creative: true } };
const SPECIAL = {
  treefeller: { kind: "cutter", rf: 30, cap: 20000 }, deep_drill: { kind: "drill", rf: 60, cap: 100000, time: 200 },
  laser_arm: { kind: "laser", rf: 128, cap: 20000, range: 128 },
  pipe_booster: { kind: "consumer", rf: 10, cap: 5000 }, drone_port: { kind: "consumer", rf: 40, cap: 50000 },
  accelerator_controller: { kind: "acc_ctrl", rf: 0, cap: 1000 }, accelerator_motor: { kind: "acc_motor", rf: 0, cap: 1000000 },
  accelerator_sensor: { kind: "acc_sensor", rf: 0, cap: 0 },
};
const TOGGLE = new Set(["tech_door", "hangar_door"]);
const DECO = new Set(["refinery_module"]);
const ORES = [["minecraft:coal", 25], ["minecraft:raw_iron", 20], ["minecraft:raw_copper", 18], ["minecraft:raw_gold", 8], ["minecraft:redstone", 10],
  ["minecraft:lapis_lazuli", 8], ["minecraft:diamond", 3], ["minecraft:emerald", 2], ["oritech:raw_nickel", 6], ["oritech:raw_platinum", 3],
  ["oritech:raw_uranium", 1], ["oritech:raw_silicon", 5]];

// ---------------- máquinas (receitas com várias entradas) ----------------
const R = (ins, outs, time) => ({ in: ins, out: outs, time });
const single = (map, time) => Object.entries(map).map(([i, [o, n]]) => R({ [i]: 1 }, [[o, n]], time));
const mk = (rf, cap, recipes, catalyst = false) => ({ rf, cap, recipes, catalyst, accepts: new Set(recipes.flatMap((r) => Object.keys(r.in))) });
const LOGS = ["oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "mangrove", "cherry"].map((w) => `minecraft:${w}_log`);

const SMELT = mk(20, 10000, single({
  "minecraft:raw_iron": ["minecraft:iron_ingot", 1], "minecraft:raw_gold": ["minecraft:gold_ingot", 1], "minecraft:raw_copper": ["minecraft:copper_ingot", 1],
  "minecraft:iron_ore": ["minecraft:iron_ingot", 1], "minecraft:deepslate_iron_ore": ["minecraft:iron_ingot", 1],
  "minecraft:gold_ore": ["minecraft:gold_ingot", 1], "minecraft:deepslate_gold_ore": ["minecraft:gold_ingot", 1],
  "minecraft:copper_ore": ["minecraft:copper_ingot", 1], "minecraft:deepslate_copper_ore": ["minecraft:copper_ingot", 1],
  "oritech:iron_dust": ["minecraft:iron_ingot", 1], "oritech:gold_dust": ["minecraft:gold_ingot", 1], "oritech:copper_dust": ["minecraft:copper_ingot", 1],
  "minecraft:sand": ["minecraft:glass", 1], "minecraft:red_sand": ["minecraft:glass", 1], "minecraft:cobblestone": ["minecraft:stone", 1],
  "minecraft:stone": ["minecraft:smooth_stone", 1], "minecraft:cobbled_deepslate": ["minecraft:deepslate", 1], "minecraft:clay_ball": ["minecraft:brick", 1],
  "minecraft:clay": ["minecraft:hardened_clay", 1], "minecraft:netherrack": ["minecraft:netherbrick", 1], "minecraft:cactus": ["minecraft:green_dye", 1],
  "minecraft:kelp": ["minecraft:dried_kelp", 1], "minecraft:potato": ["minecraft:baked_potato", 1],
  "minecraft:beef": ["minecraft:cooked_beef", 1], "minecraft:porkchop": ["minecraft:cooked_porkchop", 1], "minecraft:chicken": ["minecraft:cooked_chicken", 1],
  "minecraft:mutton": ["minecraft:cooked_mutton", 1], "minecraft:rabbit": ["minecraft:cooked_rabbit", 1], "minecraft:cod": ["minecraft:cooked_cod", 1], "minecraft:salmon": ["minecraft:cooked_salmon", 1],
  ...Object.fromEntries(LOGS.map((l) => [l, ["minecraft:charcoal", 1]])),
  "oritech:nickel_dust": ["oritech:nickel_ingot", 1], "oritech:platinum_dust": ["oritech:platinum_ingot", 1], "oritech:steel_dust": ["oritech:steel_ingot", 1],
  "oritech:electrum_dust": ["oritech:electrum_ingot", 1], "oritech:adamant_dust": ["oritech:adamant_ingot", 1], "oritech:biosteel_dust": ["oritech:biosteel_ingot", 1],
  "oritech:duratium_dust": ["oritech:duratium_ingot", 1], "oritech:energite_dust": ["oritech:energite_ingot", 1],
  "oritech:raw_nickel": ["oritech:nickel_ingot", 1], "oritech:raw_platinum": ["oritech:platinum_ingot", 1],
  "oritech:iron_gem": ["minecraft:iron_ingot", 2], "oritech:copper_gem": ["minecraft:copper_ingot", 2], "oritech:gold_gem": ["minecraft:gold_ingot", 2],
  "oritech:nickel_gem": ["oritech:nickel_ingot", 2], "oritech:platinum_gem": ["oritech:platinum_ingot", 2],
  "oritech:raw_silicon": ["oritech:silicon", 1], "oritech:polymer_resin": ["oritech:plastic_sheet", 1],
}, 100));

// receitas iguais às do Java (data/oritech/recipe/pulverizer): minério -> 2 brutos, bruto -> 1 pó + 3 pós pequenos, etc.
const G = (ins, outs, time = 100) => ins.map((i) => R({ [i]: 1 }, outs, time));
const WOOLS = ["white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray", "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"].map((c) => `minecraft:${c}_wool`);
const GRIND = mk(30, 10000, [
  // lingotes -> pó
  ...G(["minecraft:iron_ingot"], [["oritech:iron_dust", 1]]), ...G(["minecraft:gold_ingot"], [["oritech:gold_dust", 1]]),
  ...G(["minecraft:copper_ingot"], [["oritech:copper_dust", 1]]), ...G(["oritech:nickel_ingot"], [["oritech:nickel_dust", 1]]),
  ...G(["oritech:platinum_ingot"], [["oritech:platinum_dust", 1]]), ...G(["oritech:steel_ingot"], [["oritech:steel_dust", 1]]),
  ...G(["oritech:electrum_ingot"], [["oritech:electrum_dust", 1]]), ...G(["oritech:adamant_ingot"], [["oritech:adamant_dust", 1]]),
  ...G(["oritech:biosteel_ingot"], [["oritech:biosteel_dust", 1]]), ...G(["oritech:duratium_ingot"], [["oritech:duratium_dust", 1]]),
  ...G(["oritech:energite_ingot"], [["oritech:energite_dust", 1]]),
  // pepitas -> pó pequeno
  ...G(["minecraft:iron_nugget"], [["oritech:small_iron_dust", 1]]), ...G(["minecraft:gold_nugget"], [["oritech:small_gold_dust", 1]]),
  ...G(["oritech:copper_nugget"], [["oritech:small_copper_dust", 1]]), ...G(["oritech:nickel_nugget"], [["oritech:small_nickel_dust", 1]]),
  ...G(["oritech:platinum_nugget"], [["oritech:small_platinum_dust", 1]]),
  // minérios -> 2 brutos
  ...G(["minecraft:iron_ore", "minecraft:deepslate_iron_ore"], [["minecraft:raw_iron", 2]]),
  ...G(["minecraft:gold_ore", "minecraft:deepslate_gold_ore", "minecraft:nether_gold_ore"], [["minecraft:raw_gold", 2]]),
  ...G(["minecraft:copper_ore", "minecraft:deepslate_copper_ore"], [["minecraft:raw_copper", 2]]),
  // brutos -> 1 pó + 3 pós pequenos (2 slots de saída)
  ...G(["minecraft:raw_iron"], [["oritech:iron_dust", 1], ["oritech:small_iron_dust", 3]]),
  ...G(["minecraft:raw_gold"], [["oritech:gold_dust", 1], ["oritech:small_gold_dust", 3]]),
  ...G(["minecraft:raw_copper"], [["oritech:copper_dust", 1], ["oritech:small_copper_dust", 3]]),
  ...G(["oritech:raw_nickel"], [["oritech:nickel_dust", 1], ["oritech:small_nickel_dust", 3]]),
  ...G(["oritech:raw_platinum"], [["oritech:platinum_dust", 1], ["oritech:small_platinum_dust", 3]], 150),
  ...G(["oritech:raw_uranium"], [["oritech:uranium_dust", 2]]),
  // outros minérios e materiais
  ...G(["minecraft:coal_ore", "minecraft:deepslate_coal_ore"], [["minecraft:coal", 2]]),
  ...G(["minecraft:diamond_ore", "minecraft:deepslate_diamond_ore"], [["minecraft:diamond", 1]]),
  ...G(["minecraft:lapis_ore", "minecraft:deepslate_lapis_ore"], [["minecraft:lapis_lazuli", 6]]),
  ...G(["minecraft:redstone_ore", "minecraft:deepslate_redstone_ore"], [["minecraft:redstone", 8]]),
  ...G(["minecraft:quartz_ore"], [["minecraft:quartz", 2]]),
  ...G(["minecraft:coal", "minecraft:charcoal"], [["oritech:coal_dust", 1]]),
  ...G(["minecraft:quartz"], [["oritech:quartz_dust", 1]]),
  ...G(["minecraft:glowstone"], [["minecraft:glowstone_dust", 3]]),
  ...G(["minecraft:blaze_rod"], [["minecraft:blaze_powder", 3]]),
  ...G(["minecraft:bone"], [["minecraft:bone_meal", 6]]),
  ...G(["minecraft:dripstone_block"], [["minecraft:pointed_dripstone", 4]]),
  ...G(["minecraft:prismarine_shard"], [["minecraft:prismarine_crystals", 2]]),
  ...G(["minecraft:ender_pearl"], [["oritech:enderic_compound", 8]]),
  ...G(["minecraft:hay_block", "oritech:packed_wheat"], [["oritech:biomass", 16]]),
  ...G(WOOLS, [["minecraft:string", 3]]),
  // pedras e areia
  ...G(["minecraft:cobblestone", "minecraft:mossy_cobblestone", "minecraft:cobbled_deepslate"], [["minecraft:gravel", 1]]),
  ...G(["minecraft:gravel"], [["minecraft:sand", 1]]),
  ...G(["minecraft:sandstone", "minecraft:chiseled_sandstone", "minecraft:cut_sandstone", "minecraft:smooth_sandstone"], [["minecraft:sand", 1]]),
  ...G(["minecraft:red_sandstone", "minecraft:chiseled_red_sandstone", "minecraft:cut_red_sandstone", "minecraft:smooth_red_sandstone"], [["minecraft:red_sand", 1]]),
]);

const FOUNDRY = mk(40, 20000, [
  R({ "minecraft:iron_ingot": 1, "oritech:coal_dust": 1 }, [["oritech:steel_ingot", 1]], 60),
  R({ "minecraft:gold_ingot": 1, "minecraft:redstone": 1 }, [["oritech:electrum_ingot", 1]], 80),
  R({ "minecraft:gold_ingot": 1, "minecraft:netherite_scrap": 1 }, [["minecraft:netherite_ingot", 1]], 80),
  R({ "minecraft:copper_ingot": 3, "minecraft:iron_ingot": 1 }, [["minecraft:copper_block", 1]], 120),
  R({ "minecraft:diamond": 1, "oritech:nickel_ingot": 1 }, [["oritech:adamant_ingot", 1]], 80),
  R({ "oritech:raw_biopolymer": 1, "minecraft:iron_ingot": 1 }, [["oritech:biosteel_ingot", 1]], 80),
  R({ "oritech:platinum_ingot": 1, "minecraft:netherite_ingot": 1 }, [["oritech:duratium_ingot", 1]], 80),
  R({ "oritech:nickel_ingot": 1, "oritech:fluxite": 1 }, [["oritech:energite_ingot", 1]], 80),
]);

const CENTRIFUGE = mk(35, 20000, [
  R({ "oritech:coal_dust": 1 }, [["oritech:carbon_fibre_strands", 1]], 50),
  R({ "minecraft:gravel": 1 }, [["minecraft:flint", 1], ["minecraft:sand", 1]], 60),
  R({ "minecraft:clay": 1 }, [["minecraft:clay_ball", 4]], 60),
  R({ "minecraft:magma": 1 }, [["minecraft:blaze_powder", 2]], 100),
  R({ "minecraft:glowstone": 1 }, [["minecraft:glowstone_dust", 4]], 60),
  R({ "minecraft:amethyst_block": 1 }, [["minecraft:amethyst_shard", 4]], 80),
  R({ "minecraft:quartz_block": 1 }, [["minecraft:quartz", 4]], 80),
  R({ "minecraft:sculk": 1 }, [["minecraft:echo_shard", 1]], 400),
  R({ "oritech:iron_clump": 1 }, [["oritech:iron_gem", 1], ["oritech:small_nickel_dust", 3]], 100),
  R({ "oritech:copper_clump": 1 }, [["oritech:copper_gem", 1], ["oritech:small_gold_dust", 3]], 100),
  R({ "oritech:gold_clump": 1 }, [["oritech:gold_gem", 1], ["oritech:small_copper_dust", 3]], 100),
  R({ "oritech:nickel_clump": 1 }, [["oritech:nickel_gem", 1], ["oritech:small_platinum_dust", 2]], 100),
  R({ "oritech:platinum_clump": 1 }, [["oritech:platinum_gem", 1], ["oritech:fluxite", 1]], 150),
  R({ "minecraft:sand": 4 }, [["oritech:raw_silicon", 1]], 80),
  R({ "minecraft:kelp": 4 }, [["oritech:raw_biopolymer", 1]], 80),
]);

const ASSEMBLER = mk(40, 20000, [
  R({ "minecraft:blaze_powder": 4 }, [["minecraft:blaze_rod", 1]], 96),
  R({ "minecraft:honeycomb": 1, "minecraft:wheat": 3 }, [["minecraft:slime_ball", 1]], 96),
  R({ "minecraft:oak_log": 1, "minecraft:glowstone_dust": 3 }, [["minecraft:shroomlight", 1]], 96),
  R({ "minecraft:gunpowder": 1, "minecraft:blaze_powder": 1, "minecraft:coal": 2 }, [["minecraft:fire_charge", 4]], 96),
  R({ "minecraft:paper": 3, "minecraft:leather": 1 }, [["minecraft:book", 2]], 96),
  R({ "minecraft:wheat": 3, "minecraft:oak_planks": 1 }, [[BIO, 1]], 96),
  R({ "minecraft:iron_ingot": 2, "minecraft:redstone": 2, "oritech:copper_dust": 1 }, [["minecraft:comparator", 1]], 120),
  R({ "oritech:steel_ingot": 4 }, [["minecraft:iron_block", 1]], 120),
  R({ "oritech:carbon_fibre_strands": 4, "oritech:steel_ingot": 1 }, [["minecraft:elytra", 1]], 400),
  R({ "oritech:steel_ingot": 1, "oritech:nickel_ingot": 2, "minecraft:copper_ingot": 1 }, [["oritech:magnetic_coil", 6]], 96),
  R({ "oritech:magnetic_coil": 2, "oritech:steel_ingot": 2, "minecraft:redstone": 1 }, [["oritech:motor", 1]], 120),
  R({ "oritech:processing_unit": 1, "oritech:fluxite": 2, "oritech:platinum_ingot": 1 }, [["oritech:flux_gate", 1]], 120),
  R({ "minecraft:iron_ingot": 1, "minecraft:copper_ingot": 1, "minecraft:redstone": 4 }, [["oritech:basic_battery", 1]], 96),
  R({ "oritech:basic_battery": 2, "oritech:electrum_ingot": 1, "oritech:platinum_ingot": 1 }, [["oritech:advanced_battery", 1]], 160),
  R({ "oritech:carbon_fibre_strands": 4, "oritech:plastic_sheet": 1 }, [["oritech:reinforced_carbon_sheet", 1]], 120),
  R({ "minecraft:wheat": 4, "minecraft:sugar_cane": 2 }, [["oritech:biomass", 2]], 96),
  R({ "minecraft:wheat": 9 }, [["oritech:packed_wheat", 1]], 60),
  R({ "minecraft:amethyst_shard": 4, "oritech:fluxite": 1, "minecraft:redstone": 4 }, [["oritech:overcharged_crystal", 1]], 160),
  R({ "minecraft:ender_pearl": 1, "oritech:fluxite": 1 }, [["oritech:enderic_compound", 1]], 160),
  R({ "oritech:enderic_compound": 1, "minecraft:glass": 2, "minecraft:diamond": 1 }, [["oritech:enderic_lens", 1]], 200),
  R({ "oritech:raw_uranium": 2, "oritech:plastic_sheet": 1 }, [["oritech:uranium_pellet", 1]], 160),
]);
const FRAGMENT = mk(80, 50000, [
  ...["iron", "gold", "copper"].flatMap((m) => [`minecraft:${m}_ore`, `minecraft:deepslate_${m}_ore`].map((o) => R({ [o]: 1 }, [[`minecraft:raw_${m}`, 3]], 120))),
  R({ "minecraft:coal_ore": 1 }, [["minecraft:coal", 4]], 100), R({ "minecraft:deepslate_coal_ore": 1 }, [["minecraft:coal", 4]], 100),
  R({ "minecraft:lapis_ore": 1 }, [["minecraft:lapis_lazuli", 10]], 100), R({ "minecraft:deepslate_lapis_ore": 1 }, [["minecraft:lapis_lazuli", 10]], 100),
  R({ "minecraft:redstone_ore": 1 }, [["minecraft:redstone", 8]], 100), R({ "minecraft:deepslate_redstone_ore": 1 }, [["minecraft:redstone", 8]], 100),
  R({ "minecraft:diamond_ore": 1 }, [["minecraft:diamond", 2]], 140), R({ "minecraft:deepslate_diamond_ore": 1 }, [["minecraft:diamond", 2]], 140),
  R({ "minecraft:emerald_ore": 1 }, [["minecraft:emerald", 2]], 140), R({ "minecraft:deepslate_emerald_ore": 1 }, [["minecraft:emerald", 2]], 140),
  R({ "minecraft:quartz_ore": 1 }, [["minecraft:quartz", 3]], 100),
  ...["iron", "gold", "copper"].map((m) => R({ [`minecraft:raw_${m}`]: 1 }, [[`oritech:${m}_clump`, 1]], 100)),
  R({ "oritech:raw_nickel": 1 }, [["oritech:nickel_clump", 1]], 100), R({ "oritech:raw_platinum": 1 }, [["oritech:platinum_clump", 1]], 100),
]);
const ATOMIC = mk(100, 50000, [
  R({ "oritech:silicon": 2, "oritech:quartz_dust": 1 }, [["oritech:silicon_wafer", 2]], 200),
  R({ "oritech:silicon_wafer": 1, "minecraft:gold_ingot": 1, "minecraft:redstone": 4 }, [["oritech:processing_unit", 1]], 240),
  R({ "oritech:processing_unit": 2, "oritech:platinum_ingot": 1, "oritech:electrum_ingot": 1 }, [["oritech:advanced_computing_engine", 1]], 300),
  R({ "oritech:advanced_computing_engine": 1, "oritech:enderic_lens": 1, "minecraft:diamond": 1 }, [["oritech:super_ai_chip", 1]], 400),
  R({ "minecraft:netherite_scrap": 4, "minecraft:gold_ingot": 4 }, [["minecraft:netherite_ingot", 1]], 300),
  R({ "oritech:carbon_fibre_strands": 8 }, [["minecraft:diamond", 1]], 400),
]);
const COOLER = mk(32, 50000, [
  R({ "minecraft:water_bucket": 1 }, [["minecraft:ice", 1], ["minecraft:bucket", 1]], 60),
  R({ "minecraft:ice": 2 }, [["minecraft:packed_ice", 1]], 80),
  R({ "minecraft:packed_ice": 2 }, [["minecraft:blue_ice", 1]], 100),
  R({ "minecraft:lava_bucket": 1, "minecraft:water_bucket": 1 }, [["minecraft:obsidian", 1], ["minecraft:bucket", 2]], 100),
  R({ "minecraft:snowball": 4 }, [["minecraft:snow", 1]], 40),
]);
const PUMP = mk(20, 10000, [R({ "minecraft:bucket": 1 }, [["minecraft:water_bucket", 1]], 40)]);
const REFINERY = mk(64, 50000, [
  R({ "oritech:raw_biopolymer": 2, "minecraft:water_bucket": 1 }, [["oritech:polymer_resin", 1], ["minecraft:bucket", 1]], 100),
  R({ "minecraft:wheat": 8, "minecraft:water_bucket": 1 }, [[BIO, 2], ["minecraft:bucket", 1]], 100),
  R({ "oritech:coal_dust": 4, "minecraft:water_bucket": 1 }, [["oritech:carbon_fibre_strands", 2], ["minecraft:bucket", 1]], 100),
]);
const TAINTED = mk(96, 50000, [
  R({ "minecraft:ancient_debris": 1, "minecraft:blaze_powder": 2 }, [["minecraft:netherite_scrap", 2]], 200),
  R({ "minecraft:lava_bucket": 1, "minecraft:soul_sand": 4 }, [["minecraft:blaze_powder", 2], ["minecraft:bucket", 1]], 160),
  R({ "minecraft:netherrack": 8, "minecraft:lava_bucket": 1 }, [["minecraft:quartz", 4], ["minecraft:bucket", 1]], 160),
]);
const ENCHANT = mk(40, 30000, [
  R({ "minecraft:glass_bottle": 1, "minecraft:lapis_lazuli": 4, "minecraft:emerald": 1 }, [["minecraft:experience_bottle", 1]], 100),
  R({ "minecraft:apple": 1, "minecraft:gold_ingot": 4 }, [["minecraft:golden_apple", 1]], 100),
  R({ "minecraft:carrot": 1, "minecraft:gold_nugget": 8 }, [["minecraft:golden_carrot", 1]], 80),
  R({ "minecraft:melon_slice": 1, "minecraft:gold_nugget": 8 }, [["minecraft:glistering_melon_slice", 1]], 80),
]);
const CATALYST = mk(60, 50000, [
  R({ "minecraft:golden_apple": 1, "minecraft:gold_block": 4 }, [["minecraft:enchanted_golden_apple", 1]], 400),
  R({ "minecraft:ender_pearl": 1, "minecraft:blaze_powder": 1 }, [["minecraft:ender_eye", 1]], 100),
  R({ "minecraft:emerald_block": 1, "minecraft:gold_block": 2, "minecraft:diamond": 1 }, [["minecraft:totem_of_undying", 1]], 400),
  R({ "minecraft:echo_shard": 8, "minecraft:compass": 1 }, [["minecraft:recovery_compass", 1]], 300),
  R({ "minecraft:amethyst_shard": 2, "minecraft:copper_ingot": 1 }, [["minecraft:spyglass", 1]], 120),
], true);
const TOOLS = { pickaxe: 3, axe: 3, shovel: 1, sword: 2, hoe: 2, helmet: 5, chestplate: 8, leggings: 7, boots: 4 };
const AUGMENT = mk(60, 50000, [
  ...Object.entries(TOOLS).map(([t, n]) => R({ [`minecraft:iron_${t}`]: 1, "minecraft:diamond": n }, [[`minecraft:diamond_${t}`, 1]], 200)),
  ...Object.keys(TOOLS).map((t) => R({ [`minecraft:diamond_${t}`]: 1, "minecraft:netherite_ingot": 1 }, [[`minecraft:netherite_${t}`, 1]], 300)),
]);
const PACK9 = [["minecraft:iron_ingot", "minecraft:iron_block"], ["minecraft:gold_ingot", "minecraft:gold_block"], ["minecraft:copper_ingot", "minecraft:copper_block"],
  ["minecraft:diamond", "minecraft:diamond_block"], ["minecraft:emerald", "minecraft:emerald_block"], ["minecraft:redstone", "minecraft:redstone_block"],
  ["minecraft:lapis_lazuli", "minecraft:lapis_block"], ["minecraft:coal", "minecraft:coal_block"], ["minecraft:netherite_ingot", "minecraft:netherite_block"],
  ["minecraft:slime_ball", "minecraft:slime"], ["minecraft:wheat", "minecraft:hay_block"], ["minecraft:dried_kelp", "minecraft:dried_kelp_block"],
  ["minecraft:bone_meal", "minecraft:bone_block"], ["oritech:steel_ingot", "oritech:steel_block"], ["oritech:nickel_ingot", "oritech:nickel_block"],
  ["oritech:platinum_ingot", "oritech:platinum_block"], ["oritech:electrum_ingot", "oritech:electrum_block"], ["oritech:silicon", "oritech:silicon_block"],
  ["oritech:fluxite", "oritech:fluxite_block"], ["oritech:raw_nickel", "oritech:raw_nickel_block"], ["oritech:raw_platinum", "oritech:raw_platinum_block"]];
const PACK4 = [["minecraft:quartz", "minecraft:quartz_block"], ["minecraft:clay_ball", "minecraft:clay"], ["minecraft:glowstone_dust", "minecraft:glowstone"],
  ["minecraft:snowball", "minecraft:snow"], ["minecraft:sand", "minecraft:sandstone"]];
const COMPRESS = mk(40, 20000, [...PACK9.map(([a, b]) => R({ [a]: 9 }, [[b, 1]], 60)), ...PACK4.map(([a, b]) => R({ [a]: 4 }, [[b, 1]], 60))]);
const BLAST = mk(40, 20000, SMELT.recipes.filter((r) => r.out[0][0].endsWith("_ingot")).map((r) => R(r.in, [[r.out[0][0], r.out[0][1] * 2]], 60)));
const SMOKER = mk(15, 8000, SMELT.recipes.filter((r) => /cooked_|baked_|dried_kelp/.test(r.out[0][0])).map((r) => R(r.in, r.out, 40)));
const INDGRIND = mk(50, 20000, GRIND.recipes.filter((r) => r.out[0][0].endsWith("_dust")).map((r) => R(r.in, [[r.out[0][0], Math.ceil(r.out[0][1] * 1.5)]], 60)));
const MACH = { powered_furnace: SMELT, pulverizer: GRIND, foundry: FOUNDRY, centrifuge: CENTRIFUGE, assembler: ASSEMBLER,
  fragment_forge: FRAGMENT, atomic_forge: ATOMIC, cooler: COOLER, pump: PUMP, refinery: REFINERY, tainted_refinery: TAINTED,
  enchanter: ENCHANT, enchantment_catalyst: CATALYST, augment_application: AUGMENT };

// ---------------- helpers ----------------
const ctrlIds = new Set(Object.keys(MACHINES).map((k) => `oritech:${k}_block`));
const isMachineBlockId = (t) => ctrlIds.has(t) || isPartId(t);
const key = (dim, x, y, z) => `${dim.id}|${x},${y},${z}`;
const idOf = (e) => e.typeId.slice(8);
const getP = (e, k, d = 0) => e.getDynamicProperty("oritech:" + k) ?? d;
const setP = (e, k, v) => e.setDynamicProperty("oritech:" + k, v);
const prettyId = (t) => t.split(":")[1].replace(/_/g, " ");
const getInv = (e) => { try { return JSON.parse(getP(e, "inv", "{}")); } catch { return {}; } };
const setInv = (e, inv) => { for (const k of Object.keys(inv)) if (inv[k] <= 0) delete inv[k]; setP(e, "inv", JSON.stringify(inv)); };
const DIRS = [[0, 0, -1, "north"], [0, 0, 1, "south"], [1, 0, 0, "east"], [-1, 0, 0, "west"], [0, 1, 0, "up"], [0, -1, 0, "down"]];
const same = (a, b) => a.x === b.x && a.y === b.y && a.z === b.z;

// modelo -> mundo em quartos de volta (célula do modelo = (-z, x) do offset do Java)
const rq = (x, z, q) => (q === 0 ? [x, z] : q === 1 ? [z, -x] : q === 2 ? [-x, -z] : [-z, x]);
function footprint(cfg, bx, by, bz, q) {
  const out = [{ x: bx, y: by, z: bz }];                     // o controlador (bloco laranja) é sempre a 1ª célula
  for (const [vx, vy, vz] of cfg.cores) { const [wx, wz] = rq(-vz, vx, q); out.push({ x: bx + wx, y: by + vy, z: bz + wz }); }
  return out;
}
function entPos(cb, cfg, q) {
  const [wx, wz] = rq(cfg.ex / 16, cfg.ez / 16, q), c = cb.bottomCenter();
  return { x: c.x + wx, y: c.y + (cfg.ey ?? 0) / 16, z: c.z + wz };
}
const baseOf = (e) => ({ x: getP(e, "ax", Math.floor(e.location.x)), y: getP(e, "ay", Math.round(e.location.y)), z: getP(e, "az", Math.floor(e.location.z)) });
function cellsOf(e) { const b = baseOf(e); return footprint(MACHINES[idOf(e)], b.x, b.y, b.z, getP(e, "fq", 0)); }
function machineAt(dim, x, y, z) {
  const near = dim.getEntities({ families: ["oritech_machine"], location: { x: x + 0.5, y, z: z + 0.5 }, maxDistance: 8 });
  return near.find((e) => cellsOf(e).some((c) => c.x === x && c.y === y && c.z === z));
}
function spawnStacks(dim, loc, id, n) {
  while (n > 0) { const k = Math.min(n, 64); try { dim.spawnItem(new ItemStack(id, k), loc); } catch (err) { console.warn("spawn", id, err); } n -= k; }
}
function giveItem(player, id, n = 1) {
  const inv = player.getComponent("minecraft:inventory").container;
  let left = n;
  while (left > 0) { const k = Math.min(left, 64); const r = inv.addItem(new ItemStack(id, k)); if (r) player.dimension.spawnItem(r, player.location); left -= k; }
}

// ---------------- cabos e dutos ----------------
function hasInv(b) { try { return !!b.getComponent("minecraft:inventory"); } catch { return false; } }
function connects(fam, n) {
  if (!n) return false;
  if (PIPE_FAM[n.typeId] === fam) return true;
  if (isMachineBlockId(n.typeId)) return true;
  if (rxConnects(fam, n.typeId)) return true;
  return fam !== "energy" && hasInv(n);
}
function refreshCable(b) {
  if (!b || !PIPE_FAM[b.typeId] || DUCT.has(b.typeId)) return;
  const fam = PIPE_FAM[b.typeId];
  let perm = b.permutation, changed = false;
  for (const [dx, dy, dz, name] of DIRS) {
    const n = b.dimension.getBlock({ x: b.x + dx, y: b.y + dy, z: b.z + dz });
    const st = "oritech:no_" + name, want = !connects(fam, n);
    if (perm.getState(st) !== want) { perm = perm.withState(st, want); changed = true; }
  }
  if (changed) b.setPermutation(perm);
}
function refreshAround(dim, x, y, z) {
  for (const [dx, dy, dz] of [[0, 0, 0], ...DIRS]) refreshCable(dim.getBlock({ x: x + dx, y: y + dy, z: z + dz }));
}
function refreshCells(dim, cells) { cells.forEach((c) => refreshAround(dim, c.x, c.y, c.z)); }

// rede de dutos (itens/fluidos): máquinas e inventários alcançáveis a partir de uma máquina
function pipeNet(dim, cells, fam) {
  const own = new Set(cells.map((c) => `${c.x},${c.y},${c.z}`));
  const res = { machines: new Map(), invs: new Map() }, seen = new Set(), stack = [];
  const visit = (x, y, z) => {
    for (const [dx, dy, dz] of DIRS) {
      const nx = x + dx, ny = y + dy, nz = z + dz, k = `${nx},${ny},${nz}`;
      if (own.has(k) || seen.has(k)) continue;
      const n = dim.getBlock({ x: nx, y: ny, z: nz });
      if (!n) continue;
      if (PIPE_FAM[n.typeId] === fam) { seen.add(k); stack.push(n); }
      else if (isMachineBlockId(n.typeId)) { const t = machineAt(dim, nx, ny, nz); if (t) res.machines.set(t.id, t); }
      else if (fam === "item" && rxIsPort(n.typeId)) { const rr = rxAt(dim, nx, ny, nz); if (rr) res.machines.set(rr.e.id, rr.e); }
      else if (fam !== "energy" && hasInv(n)) res.invs.set(k, n);
    }
  };
  cells.forEach((c) => visit(c.x, c.y, c.z));
  let guard = 0;
  while (stack.length && guard++ < 500) { const p = stack.pop(); visit(p.x, p.y, p.z); }
  return res;
}
// entrega itens da máquina src pelos dutos; devolve quantos sobraram
function deliver(src, id, count, depth = 0) {
  const dim = src.dimension, cells = cellsOf(src);
  const fams = id.endsWith("_bucket") || id === "minecraft:bucket" ? ["fluid", "item"] : ["item"];
  let left = count;
  for (const fam of fams) {
    if (left <= 0) break;
    const net = pipeNet(dim, cells, fam);
    for (const t of net.machines.values()) {
      if (t.id === src.id) continue;
      const r = tryInsert(t, id, left);
      if (r.n > 0) {
        left -= r.n;
        if (r.ret) { const rest = depth < 2 ? deliver(t, r.ret, r.n, depth + 1) : r.n; if (rest > 0) spawnStacks(dim, { x: t.location.x, y: t.location.y + 2, z: t.location.z }, r.ret, rest); }
      }
      if (left <= 0) break;
    }
    for (const inv of net.invs.values()) {
      if (left <= 0) break;
      const c = inv.getComponent("minecraft:inventory")?.container;
      if (!c) continue;
      while (left > 0) {
        const k = Math.min(left, 64), rest = c.addItem(new ItemStack(id, k));
        const moved = k - (rest ? rest.amount : 0);
        left -= moved;
        if (rest) break;
      }
    }
  }
  return left;
}
// puxa itens de baús/barris ligados por cano de itens
function pullItems(m) {
  const net = pipeNet(m.dim, m.cells, "item");
  for (const inv of net.invs.values()) {
    const c = inv.getComponent("minecraft:inventory")?.container;
    if (!c) continue;
    for (let s = 0; s < c.size; s++) {
      const it = c.getItem(s);
      if (!it) continue;
      const r = tryInsert(m.e, it.typeId, Math.min(it.amount, 16));
      if (r.n > 0) {
        if (it.amount > r.n) { it.amount -= r.n; c.setItem(s, it); } else c.setItem(s, undefined);
        if (r.ret) { const rest = deliver(m.e, r.ret, r.n); if (rest > 0) spawnStacks(m.dim, { x: m.e.location.x, y: m.e.location.y + 2, z: m.e.location.z }, r.ret, rest); }
        return;
      }
    }
  }
}

// ---------------- blueprint: blocos fantasma + núcleos ----------------
function ctrlInfo(b, perm) {
  const id = b.typeId.slice(8, -6), cfg = MACHINES[id];
  const dir = (perm ?? b.permutation).getState("minecraft:cardinal_direction") ?? "south";
  const k = id === "big_solar_panel" ? solarYaw() : (FACE[dir] ?? 0);   // painel solar: eixo de inclinação sempre norte-sul
  const q = (((2 - k + footRot()) % 4) + 4) % 4;
  return { id, cfg, dir, k, q, block: b, cells: cfg ? footprint(cfg, b.x, b.y, b.z, q) : [] };
}
function findBlueprint(dim, p) {
  for (let dy = -4; dy <= 0; dy++) for (let dx = -4; dx <= 4; dx++) for (let dz = -4; dz <= 4; dz++) {
    const b = dim.getBlock({ x: p.x + dx, y: p.y + dy, z: p.z + dz });
    if (!b || !ctrlIds.has(b.typeId) || b.permutation.getState("oritech:built") !== false) continue;
    const info = ctrlInfo(b);
    if (info.cfg && info.cells.some((c) => same(c, p))) return info;
  }
  return undefined;
}
const missing = (dim, bp) => bp.cells.filter((c) => !same(c, bp.block) && !coreColor(dim.getBlock(c)?.typeId ?? "")).length;
function assemble(dim, bp) {
  const others = bp.cells.filter((c) => !same(c, bp.block));
  const blocks = others.map((c) => dim.getBlock(c));
  if (blocks.some((b) => !b || !coreColor(b.typeId))) return false;
  const skin = bp.cfg.skin ?? 0;
  blocks.forEach((b) => b.setType(bp.cfg.door ? DOOR_PART : PART));
  const cb = bp.block;
  cb.setPermutation(cb.permutation.withState("oritech:built", true));
  const epos = entPos(cb, bp.cfg, bp.q);
  const e = dim.spawnEntity("oritech:" + bp.id, epos);
  e.teleport(epos, { dimension: dim, rotation: { x: 0, y: 0 } });
  const face = bp.k;
  e.triggerEvent("oritech:face_" + (FLIP_FRONT ? (face + 2) % 4 : face));
  e.triggerEvent("oritech:skin_" + skin);
  setP(e, "ax", cb.x); setP(e, "ay", cb.y); setP(e, "az", cb.z);
  setP(e, "energy", 0); setP(e, "burn", 0); setP(e, "water", 0); setP(e, "vs", 0); setP(e, "open", 0); setP(e, "skin", skin);
  setP(e, "inv", "{}"); setP(e, "prog", 0); setP(e, "rec", -1); setP(e, "fq", bp.q);
  setP(e, "deploy", bp.cfg.deploy);
  if (!bp.cfg.deploy) e.triggerEvent("oritech:set_idle");
  dim.playSound("random.anvil_use", cb.center(), { volume: 0.6, pitch: 1.3 });
  refreshCells(dim, bp.cells);
  return true;
}
function dismantle(e, drop) {
  const dim = e.dimension, cells = cellsOf(e), id = idOf(e);
  for (const p of cells) {
    const b = dim.getBlock(p);
    if (b && isMachineBlockId(b.typeId)) b.setType("minecraft:air");
  }
  if (drop) {
    dim.spawnItem(new ItemStack("oritech:" + id, 1), { x: e.location.x, y: e.location.y + 0.5, z: e.location.z });
    guiDropContents(e);
  }
  e.remove();
  system.runTimeout(() => refreshCells(dim, cells), 2);
}


// ---------------- acelerador de partículas (regras do Java, simplificadas) ----------------
// partícula nasce com velocidade 1; cada motor ao lado do caminho gasta (velocidade x 10) RF e soma +1 de velocidade;
// distância máxima entre anéis = clamp(sqrt(v)/2, 2, 10); curva exige trecho reto >= sqrt(v)/2,5;
// duas partículas em rota de colisão somam a velocidade e tentam uma receita; sem anel à frente a partícula sai em linha reta
const ACC = { RF: 10, BEND: 2.5, GATE: 10, COLL_MUL: 2, parts: [], seq: 1 };
const ACC_RING = "oritech:accelerator_ring", ACC_SENSOR = "oritech:accelerator_sensor_block", ACC_COLLECTOR = null;
const accGate = (t) => t === ACC_RING || t === ACC_SENSOR;
const ACC_DIRS = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
const PCOLL = [{"in": ["oritech:coal_dust", "oritech:coal_dust"], "out": "minecraft:diamond", "time": 500}, {"in": ["minecraft:ender_pearl", "minecraft:amethyst_shard"], "out": "minecraft:echo_shard", "time": 1000}, {"in": ["minecraft:feather", "minecraft:saddle"], "out": "minecraft:elytra", "time": 10000}, {"in": ["minecraft:redstone", "minecraft:rotten_flesh"], "out": "oritech:enderic_compound", "time": 500}, {"in": ["oritech:electrum_dust", "minecraft:redstone"], "out": "oritech:fluxite", "time": 1000}, {"in": ["oritech:overcharged_crystal", "minecraft:netherite_ingot"], "out": "minecraft:nether_star", "time": 15000}, {"in": ["oritech:adamant_dust", "minecraft:netherrack"], "out": "minecraft:netherite_scrap", "time": 2500}, {"in": ["oritech:fluxite", "oritech:energite_dust"], "out": "oritech:overcharged_crystal", "time": 5000}, {"in": ["oritech:gold_dust", "oritech:gold_dust"], "out": "oritech:platinum_dust", "time": 500}, {"in": ["oritech:uranium_dust", "oritech:fluxite"], "out": "oritech:plutonium_dust", "time": 2500}];
const pk = (x, y, z) => `${x},${y},${z}`;
function accInject(m) {
  const { e, dim, base } = m;
  if (ACC.parts.some((q) => q.ctrl === e.id)) return;
  const inv = getInv(e), k = Object.keys(inv)[0];
  if (!k) return;
  let dir = null;
  for (const d of ACC_DIRS) { const b = dim.getBlock({ x: base.x + d[0], y: base.y + d[1], z: base.z + d[2] }); if (b && accGate(b.typeId)) { dir = d; break; } }
  if (!dir) return;
  inv[k] -= 1; setInv(e, inv);
  ACC.parts.push({ id: ACC.seq++, dim, ctrl: e.id, ctrlE: e, item: k, speed: 1, pos: { x: base.x + dir[0], y: base.y + dir[1], z: base.z + dir[2] }, prev: { x: base.x, y: base.y, z: base.z }, dir, run: 1, adj: new Set(), alive: true, budget: 0 });
  dim.playSound("random.click", e.location, { volume: 0.8, pitch: 0.6 });
}
function accCtx(dim) {
  const motors = new Map(), sensors = new Map();
  for (const en of dim.getEntities({ type: "oritech:accelerator_motor" })) { const b = baseOf(en); motors.set(pk(b.x, b.y, b.z), en); }
  for (const en of dim.getEntities({ type: "oritech:accelerator_sensor" })) { const b = baseOf(en); sensors.set(pk(b.x, b.y, b.z), en); }
  return { motors, sensors };
}
function accGo(p, x, y, z, typeId, ctx, dist) {
  p.prev = p.pos; p.pos = { x, y, z }; p.run += dist;
  const cur = new Set();
  for (const d of ACC_DIRS) { const k = pk(x + d[0], y + d[1], z + d[2]); if (ctx.motors.has(k)) cur.add(k); }
  for (const k of cur) {
    if (p.adj.has(k)) continue;
    const me = ctx.motors.get(k), cost = p.speed * ACC.RF, en = getP(me, "energy");
    if (en >= cost) { setP(me, "energy", en - cost); p.speed += 1; }
  }
  p.adj = cur;
  if (typeId === ACC_SENSOR) { const se = ctx.sensors.get(pk(x, y, z)); if (se) setP(se, "speed", p.speed); }
}
function accMove(p, ctx) {
  const dim = p.dim, v = p.speed, [dx, dy, dz] = p.dir, at = (x, y, z) => dim.getBlock({ x, y, z });
  const nb = at(p.pos.x + dx, p.pos.y + dy, p.pos.z + dz);
  if (nb && accGate(nb.typeId)) { accGo(p, p.pos.x + dx, p.pos.y + dy, p.pos.z + dz, nb.typeId, ctx, 1); return true; }
  const maxGap = Math.floor(Math.max(2, Math.min(ACC.GATE, Math.sqrt(v) / 2)));
  for (let g = 2; g <= maxGap; g++) {
    const b = at(p.pos.x + dx * g, p.pos.y + dy * g, p.pos.z + dz * g);
    if (b && accGate(b.typeId)) { accGo(p, p.pos.x + dx * g, p.pos.y + dy * g, p.pos.z + dz * g, b.typeId, ctx, g); return true; }
  }
  if (p.run >= Math.sqrt(v) / ACC.BEND) {
    for (const d of ACC_DIRS) {
      if ((d[0] === -dx && d[1] === -dy && d[2] === -dz) || (d[0] === dx && d[1] === dy && d[2] === dz)) continue;
      const b = at(p.pos.x + d[0], p.pos.y + d[1], p.pos.z + d[2]);
      if (b && accGate(b.typeId)) { p.dir = d; p.run = 0; accGo(p, p.pos.x + d[0], p.pos.y + d[1], p.pos.z + d[2], b.typeId, ctx, 1); return true; }
    }
  }
  return false;
}
function accFx(dim, pos, id) { /* partículas do acelerador removidas a pedido; lógica e sons continuam */ }
function accExit(p) {
  const dim = p.dim; let [dx, dy, dz] = p.dir, x = p.pos.x, y = p.pos.y, z = p.pos.z;
  for (let i = 0; i < 48; i++) {
    x += dx; y += dy; z += dz;
    const b = dim.getBlock({ x, y, z });
    if (!b) break;
    if (b.typeId === ACC_COLLECTOR) {
      const ce = machineAt(dim, x, y, z);
      if (ce) setP(ce, "energy", Math.min(5000000, getP(ce, "energy") + Math.floor(p.speed * p.speed * ACC.COLL_MUL)));
      accFx(dim, { x, y, z }, "minecraft:electric_spark_particle"); dim.playSound("random.orb", { x, y, z }, { volume: 0.8, pitch: 1.5 });
      break;
    }
    if (!b.isAir && !b.isLiquid) {
      accFx(dim, { x, y, z }, "minecraft:large_explosion");
      if (p.speed >= 300 && !b.typeId.startsWith("oritech:") && !["minecraft:bedrock", "minecraft:barrier", "minecraft:end_portal_frame"].includes(b.typeId)) { try { dim.runCommand(`setblock ${x} ${y} ${z} air destroy`); } catch (err) { /* ignora */ } }
      break;
    }
    try { for (const en of dim.getEntities({ location: { x: x + 0.5, y: y + 0.5, z: z + 0.5 }, maxDistance: 0.9 })) { if (en.typeId === "minecraft:item" || en.typeId.startsWith("oritech:")) continue; try { en.applyDamage(Math.min(200, p.speed / 10)); } catch (err) { /* ignora */ } } } catch (err) { /* ignora */ }
  }
  p.alive = false;
}
function accCollide(a, b) {
  const dim = a.dim, E = a.speed + b.speed, pos = a.pos;
  const r = PCOLL.find((q) => ((q.in[0] === a.item && q.in[1] === b.item) || (q.in[0] === b.item && q.in[1] === a.item)) && E >= q.time);
  if (r) {
    const ce = [a.ctrlE, b.ctrlE].find((x) => { try { return x && x.isValid; } catch { return false; } });
    if (ce) { const left = deliver(ce, r.out, 1); if (left > 0) spawnStacks(dim, { x: pos.x + 0.5, y: pos.y + 1, z: pos.z + 0.5 }, r.out, left); }
    else spawnStacks(dim, { x: pos.x + 0.5, y: pos.y + 1, z: pos.z + 0.5 }, r.out, 1);
    accFx(dim, pos, "minecraft:totem_particle"); dim.playSound("random.levelup", { x: pos.x, y: pos.y, z: pos.z }, { volume: 0.7, pitch: 1.4 });
  } else { accFx(dim, pos, "minecraft:large_explosion"); dim.playSound("random.fizz", { x: pos.x, y: pos.y, z: pos.z }, { volume: 0.7 }); }
  a.alive = false; b.alive = false;
}
function accStep() {
  const ps = ACC.parts;
  if (!ps.length) return;
  const ctxs = new Map();
  for (const p of ps) { if (!ctxs.has(p.dim.id)) ctxs.set(p.dim.id, accCtx(p.dim)); p.budget = Math.min(60, 1 + Math.floor(p.speed / 25)); }
  for (let round = 0; round < 60; round++) {
    let any = false;
    for (const p of ps) {
      if (!p.alive || p.budget <= 0) continue;
      any = true; p.budget--;
      if (!accMove(p, ctxs.get(p.dim.id))) accExit(p);
    }
    for (let i = 0; i < ps.length; i++) for (let j = i + 1; j < ps.length; j++) {
      const a = ps[i], b = ps[j];
      if (!a.alive || !b.alive || a.dim !== b.dim) continue;
      if ((same(a.pos, b.pos)) || (same(a.pos, b.prev) && same(a.prev, b.pos))) accCollide(a, b);
    }
    if (!any) break;
  }
  for (const p of ps) if (p.alive) accFx(p.dim, p.pos, "minecraft:endrod");
  ACC.parts = ps.filter((p) => p.alive);
}
system.runInterval(() => { try { accStep(); } catch (err) { console.warn("oritech acelerador:", err); } }, 2);

// anéis: eixo do modelo segue os vizinhos (x, z ou y)
function ringApply(dim, pos) {
  const b = dim.getBlock(pos);
  if (!b || b.typeId !== ACC_RING) return;
  const cnt = [0, 0, 0];
  for (const [dx, dy, dz] of ACC_DIRS) { const n = dim.getBlock({ x: pos.x + dx, y: pos.y + dy, z: pos.z + dz }); if (n && accGate(n.typeId)) cnt[dx ? 0 : dz ? 1 : 2]++; }
  const cur = b.permutation.getState("oritech:axis") ?? 0, best = Math.max(...cnt);
  if (!best || cnt[cur] === best) return;
  b.setPermutation(b.permutation.withState("oritech:axis", cnt.indexOf(best)));
}
function ringAround(dim, pos) {
  ringApply(dim, pos);
  for (const [dx, dy, dz] of ACC_DIRS) ringApply(dim, { x: pos.x + dx, y: pos.y + dy, z: pos.z + dz });
}

// ---- texturas conectadas do casing do reator (equivalente ao Athena CTM do Java) ----
// estados oritech:c_* = "há bloco do casco nesse vizinho"; o modelo escolhe a textura de cada quadrante da face
const CTM_OFFS = [[1,0,0,"px"],[-1,0,0,"nx"],[0,1,0,"py"],[0,-1,0,"ny"],[0,0,1,"pz"],[0,0,-1,"nz"]]
  .map(([dx, dy, dz, k]) => ({ dx, dy, dz, key: "oritech:c_" + k }));
function ctmApply(dim, pos) {
  const b = dim.getBlock(pos);
  if (!b || b.typeId !== RX.ID.wall) return;
  let perm = b.permutation, changed = false;
  const fl = String(world.getDynamicProperty("oritech:ctm") ?? "");
  for (const o of CTM_OFFS) {
    const nb = dim.getBlock({ x: pos.x + o.dx, y: pos.y + o.dy, z: pos.z + o.dz });
    const on = !!nb && RX.SHELL.has(nb.typeId);
    const key = fl.includes(o.key.slice(-1)) ? o.key.replace(/c_([pn])/, (_, c) => "c_" + (c === "p" ? "n" : "p")) : o.key;
    if (perm.getState(key) !== on) { perm = perm.withState(key, on); changed = true; }
  }
  if (changed) b.setPermutation(perm);
}
function ctmAround(dim, pos) {
  ctmApply(dim, pos);
  for (const o of CTM_OFFS) ctmApply(dim, { x: pos.x + o.dx, y: pos.y + o.dy, z: pos.z + o.dz });
}
function ctmRefreshNear(dim, c, r = 20) {
  system.runJob((function* () {
    let n = 0;
    for (let x = Math.floor(c.x) - r; x <= Math.floor(c.x) + r; x++) for (let y = Math.max(-64, Math.floor(c.y) - r); y <= Math.floor(c.y) + r; y++) for (let z = Math.floor(c.z) - r; z <= Math.floor(c.z) + r; z++) {
      const b = dim.getBlock({ x, y, z });
      if (b && b.typeId === RX.ID.wall) ctmApply(dim, { x, y, z });
      if ((++n & 511) === 0) yield;
    }
  })());
}
function ctmFlood(dim, start) {   // reaplica em todo o casco conectado (reatores montados antes desta versão)
  system.runJob((function* () {
    const key = (p) => p.x + "," + p.y + "," + p.z, seen = new Set([key(start)]), st = [start];
    let n = 0;
    while (st.length && n < 60000) {
      const p = st.pop(), b = dim.getBlock(p);
      if (!b || !RX.SHELL.has(b.typeId)) continue;
      n++; ctmApply(dim, p);
      for (const [dx, dy, dz] of [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]) {
        const np = { x: p.x + dx, y: p.y + dy, z: p.z + dz }, k = key(np);
        if (!seen.has(k)) { seen.add(k); st.push(np); }
      }
      if (n % 150 === 0) yield;
    }
  })());
}
world.afterEvents.blockExplode.subscribe(({ dimension, block, explodedBlockPermutation }) => {
  if (RX.SHELL.has(explodedBlockPermutation.type.id)) ctmAround(dimension, { x: block.x, y: block.y, z: block.z });
});

world.afterEvents.playerPlaceBlock.subscribe(({ block, player }) => {
  const dim = block.dimension, t = block.typeId;
  if (accGate(t)) system.run(() => ringAround(dim, { x: block.x, y: block.y, z: block.z }));
  if (RX.SHELL.has(t)) ctmAround(dim, { x: block.x, y: block.y, z: block.z });
  if (RX.isReactorBlock(t)) return rxOnPlace(dim, block, player);
  if (PIPE_FAM[t]) return refreshAround(dim, block.x, block.y, block.z);
  if (!ctrlIds.has(t)) return;
  const bp = ctrlInfo(block);
  if (!bp.cfg) return;
  const others = bp.cells.filter((c) => !same(c, block));
  const blocked = others.some((c) => { const b = dim.getBlock(c); return !b || !(b.isAir || b.isLiquid); });
  if (blocked) {
    block.setType("minecraft:air");
    if (player.getGameMode() !== GameMode.Creative) giveItem(player, "oritech:" + bp.id);
    player.onScreenDisplay.setActionBar({ rawtext: [{ translate: "oritech.status.no_space" }, { text: ` ${bp.cells.length}` }, { translate: "oritech.status.free_blocks" }] });
    return;
  }
  others.forEach((c) => dim.getBlock(c).setType(GHOST));
  if (!others.length) assemble(dim, bp);
  else player.onScreenDisplay.setActionBar({ rawtext: [{ translate: "oritech.status.project_created" }, { text: ` ${others.length} ` }, { translate: "oritech.status.machine_cores" }] });
});

// clicar com um núcleo no controlador (bloco laranja) encaixa o próximo núcleo que falta, como no Java;
// clicar direto num bloco fantasma também funciona
world.beforeEvents.playerInteractWithBlock.subscribe((ev) => {
  const { block, itemStack, player, isFirstEvent } = ev;
  if (!itemStack || !coreColor(itemStack.typeId)) return;
  const isGhost = block.typeId === GHOST;
  const isCtrl = ctrlIds.has(block.typeId) && block.permutation.getState("oritech:built") === false;
  if (!isGhost && !isCtrl) return;
  ev.cancel = true;
  if (!isFirstEvent) return;
  const dim = block.dimension, bpos = { x: block.x, y: block.y, z: block.z }, type = itemStack.typeId, slot = player.selectedSlotIndex;
  system.run(() => {
    let pos = bpos, bp;
    if (isCtrl) {
      const cb = dim.getBlock(bpos);
      if (!cb) return;
      bp = ctrlInfo(cb);
      const next = bp.cells.find((c) => { if (same(c, bpos)) return false; const b = dim.getBlock(c); return !!b && (b.typeId === GHOST || b.isAir); });
      if (!next) return;
      pos = { x: next.x, y: next.y, z: next.z };
    }
    const b = dim.getBlock(pos);
    if (!b || (b.typeId !== GHOST && !b.isAir)) return;
    b.setType(type);
    if (player.getGameMode() !== GameMode.Creative) {
      const inv = player.getComponent("minecraft:inventory").container, it = inv.getItem(slot);
      if (it && it.typeId === type) { if (it.amount > 1) { it.amount -= 1; inv.setItem(slot, it); } else inv.setItem(slot, undefined); }
    }
    dim.playSound("random.click", { x: pos.x + 0.5, y: pos.y + 0.5, z: pos.z + 0.5 }, { volume: 0.7, pitch: 1.2 });
    bp = bp ?? findBlueprint(dim, pos);
    if (!bp) return;
    if (!assemble(dim, bp)) player.onScreenDisplay.setActionBar({ rawtext: [{ translate: "oritech.status.missing_cores" }, { text: ` ${missing(dim, bp)}` }] });
  });
});

world.afterEvents.playerBreakBlock.subscribe(({ brokenBlockPermutation: p, block, player }) => {
  const t = p.type.id, dim = block.dimension, pos = { x: block.x, y: block.y, z: block.z };
  const creative = player.getGameMode() === GameMode.Creative;
  if (RX.SHELL.has(t)) ctmAround(dim, pos);
  if (accGate(t)) system.run(() => ringAround(dim, pos));
  if (RX.isReactorBlock(t)) { rxOnBreak(dim, pos, t, player); return; }
  if (PIPE_FAM[t]) { system.runTimeout(() => refreshAround(dim, pos.x, pos.y, pos.z), 1); return; }
  if (t === GHOST || coreColor(t)) {                     // remover núcleo/fantasma de um projeto: restaura o fantasma
    system.runTimeout(() => { const b = dim.getBlock(pos); if (b && b.isAir && findBlueprint(dim, pos)) b.setType(GHOST); }, 1);
    return;
  }
  if (ctrlIds.has(t) && p.getState("oritech:built") === false) {   // cancelar projeto
    const info = ctrlInfo(block, p);
    for (const c of info.cells) {
      const b = dim.getBlock(c);
      if (!b || same(c, pos)) continue;
      if (b.typeId === GHOST) b.setType("minecraft:air");
      else if (coreColor(b.typeId)) { dim.spawnItem(new ItemStack(b.typeId, 1), { x: c.x + 0.5, y: c.y + 0.5, z: c.z + 0.5 }); b.setType("minecraft:air"); }
    }
    if (!creative) dim.spawnItem(new ItemStack("oritech:" + info.id, 1), { x: pos.x + 0.5, y: pos.y + 0.5, z: pos.z + 0.5 });
    return;
  }
  if (!isMachineBlockId(t)) return;
  const e = machineAt(dim, pos.x, pos.y, pos.z);
  if (e) dismantle(e, !creative);
});

// ---------------- itens: inserir ----------------
// retorna { n: quantos aceitou, ret: id devolvido (1 por item) }
function tryInsert(e, id, amount) {
  const mid = idOf(e), g = GEN[mid], m = MACH[mid];
  if (mid === "nuclear_reactor") return rxInsert(e, id, amount);
  if (mid === "accelerator_controller") {
    const inv = getInv(e), cur = Object.keys(inv)[0];
    if ((cur && cur !== id) || isMachineBlockId(id) || id.startsWith("oritech:machine_core_")) return { n: 0 };
    const n = Math.min(amount, 64 - (inv[id] ?? 0));
    if (n > 0) { inv[id] = (inv[id] ?? 0) + n; setInv(e, inv); }
    return { n: Math.max(0, n) };
  }
  if (g) {
    if (g.fuels[id]) {
      const t = g.fuels[id], burn = getP(e, "burn");
      const n = Math.min(amount, Math.floor((24000 - burn) / t));
      if (n > 0) setP(e, "burn", burn + n * t);
      return { n: Math.max(0, n), ret: n > 0 && id.endsWith("_bucket") ? g.returns : undefined };
    }
    if (g.water && g.water[id]) {
      const t = g.water[id], wt = getP(e, "water");
      const n = Math.min(amount, Math.floor((24000 - wt) / t));
      if (n > 0) setP(e, "water", wt + n * t);
      return { n: Math.max(0, n), ret: n > 0 ? g.returns : undefined };
    }
    return { n: 0 };
  }
  if (m && m.accepts.has(id)) {
    const inv = getInv(e), have = inv[id] ?? 0, n = Math.min(amount, 512 - have);
    if (n > 0) { inv[id] = have + n; setInv(e, inv); }
    return { n: Math.max(0, n) };
  }
  return { n: 0 };
}

function tr(key, fallbackText=null) { return { translate: key, ...(fallbackText !== null ? { with: [fallbackText] } : {}) }; }
function txt(text) { return { text: String(text) }; }
function line(...parts) { return { rawtext: parts.flatMap((p,i) => i ? [txt("\n"), p] : [p]) }; }
function status(e) {
  const id = idOf(e), g = GEN[id], m = MACH[id], sp = SPECIAL[id], st = STORE[id];
  const nameKey = `item.oritech:${id}`;
  const parts = [tr(nameKey)];
  const add = (...x) => { parts.push(txt("\n"), ...x); };
  if (TOGGLE.has(id)) return line(tr(nameKey), tr(`oritech.status.state_open`), txt(" "), tr(getP(e, "open") ? "oritech.status.open" : "oritech.status.closed"), txt(" "), tr("oritech.status.click_toggle"));
  if (DECO.has(id)) return line(tr(nameKey), tr("oritech.status.animated_decorative"));
  const cap = (g ?? m ?? sp ?? st).cap, en = getP(e, "energy");
  add(tr("oritech.status.energy"), txt(": "), txt(Math.floor(en).toLocaleString()), txt(" / "), txt(cap.toLocaleString()), txt(" RF"));
  if (g && g.solar) {
    add(tr("oritech.status.solar"), txt(": "), tr(getP(e, "sun", 0) === 1 ? "oritech.status.generating" : "oritech.status.no_sun"));
  } else if (g) {
    add(tr("oritech.status.fuel"), txt(": "), txt(Math.round(getP(e, "burn") / 20)), txt("s"));
    if (g.water) { add(tr("oritech.status.water"), txt(": "), txt(Math.round(getP(e, "water") / 20)), txt("s")); }
  }
  if (id === "accelerator_controller") {
    const inv = getInv(e), k = Object.keys(inv)[0], pa = ACC.parts.find((q) => q.ctrl === e.id);
    add(tr("oritech.status.item"), txt(": "), txt(k ? `${inv[k]}x ${prettyId(k)}` : ""));
    add(tr(pa ? "oritech.status.particle_flying" : "oritech.status.no_particle"), pa ? txt(`: ${Math.floor(pa.speed)}`) : txt("") );
  } else if (id === "accelerator_motor") add(tr("oritech.status.accelerator_motor"));
  else if (id === "accelerator_sensor") { add(tr("oritech.status.last_speed"), txt(": "), txt(Math.floor(getP(e, "speed", 0)))); add(tr("oritech.status.ring_part")); }
  else if (sp) {
    if (sp.kind === "drill") add(tr("oritech.status.progress"), txt(": "), txt(Math.floor((getP(e, "prog") / sp.time) * 100)), txt("%"));
    else if (sp.kind === "cutter") add(tr("oritech.status.tree_cutter"));
    else if (sp.kind === "laser") { const lt = laserTarget(e); add(txt(`Alcance: ${sp.range}`)); add(txt(lt ? `Alvo: [${lt.x}, ${lt.y}, ${lt.z}]` : "Sem alvo (use o Designador de Alvo)")); }
    else add(tr("oritech.status.state"), txt(": "), tr(getP(e, "vs") === 1 ? "oritech.status.active" : "oritech.status.no_energy"));
  }
  if (st && st.creative) add(tr("oritech.status.infinite_energy"));
  if (m) {
    const inv = getInv(e), keys = Object.keys(inv);
    add(tr("oritech.status.input"), txt(": "), txt(keys.length ? keys.map((k) => `${inv[k]}x ${prettyId(k)}`).join(", ") : ""));
    if (!keys.length) add(tr("oritech.status.empty_machine"));
    const ri = getP(e, "rec", -1);
    if (ri >= 0 && m.recipes[ri]) add(tr("oritech.status.progress"), txt(": "), txt(Math.floor((getP(e, "prog") / m.recipes[ri].time) * 100)), txt("%"));
  }
  return { rawtext: parts };
}
function setSkin(e, i) { e.triggerEvent("oritech:skin_" + i); setP(e, "skin", i); }
function setDoor(e, open) {
  setP(e, "open", open ? 1 : 0);
  e.triggerEvent(open ? "oritech:set_folded" : "oritech:set_idle");
  for (const c of cellsOf(e)) {
    const b = e.dimension.getBlock(c);
    if (b && (ctrlIds.has(b.typeId) || b.typeId === DOOR_PART)) b.setPermutation(b.permutation.withState("oritech:solid", !open));
  }
  e.dimension.playSound(open ? "random.door_open" : "random.door_close", e.location, { volume: 0.8 });
}

// ---------------- interação (componente de bloco: funciona com qualquer item/mão vazia) ----------------
const lastUse = new Map();
function handleInteract(block, player) {
  if (!block || !player) return;
  const isRx = RX.isReactorBlock(block.typeId);
  if (!isRx && !isMachineBlockId(block.typeId)) return;
  const tick = system.currentTick;
  if (tick - (lastUse.get(player.id) ?? -10) < 3) return;       // evita processar 2x o mesmo clique
  lastUse.set(player.id, tick);
  if (isRx) return rxInteract(block, player);
  const dim = block.dimension;
  if (ctrlIds.has(block.typeId) && block.permutation.getState("oritech:built") === false) {
    const bp = ctrlInfo(block);
    player.onScreenDisplay.setActionBar({ rawtext: [{ translate: `item.oritech:${bp.id}` }, { text: "\n" }, { translate: "oritech.status.missing_cores" }, { text: ` ${missing(dim, bp)}` }] });
    return;
  }
  const e = machineAt(dim, block.x, block.y, block.z);
  if (!e) return;
  const id = idOf(e);
  const inv = player.getComponent("minecraft:inventory").container;
  const slot = player.selectedSlotIndex;
  const held = inv.getItem(slot);
  const creative = player.getGameMode() === GameMode.Creative;
  const consume = (n) => { if (creative) return; if (held.amount > n) { held.amount -= n; inv.setItem(slot, held); } else inv.setItem(slot, undefined); };

  if (held && PAINTS[held.typeId] !== undefined) { setSkin(e, PAINTS[held.typeId]); consume(1); dim.playSound("random.orb", e.location, { volume: 0.6 }); return; }
  if (TOGGLE.has(id)) { setDoor(e, !getP(e, "open")); return; }
  if (held) {
    const r = tryInsert(e, held.typeId, held.amount);
    if (r.n > 0) {
      consume(r.n);
      if (r.ret && !creative) giveItem(player, r.ret, r.n);
      dim.playSound("random.click", e.location, { volume: 0.6 });
    }
  } else if (player.isSneaking && MACH[id]) {
    for (const [k, n] of Object.entries(getInv(e))) giveItem(player, k, n);
    if (GUI_MACH[id]) guiTakeAll(e, player);
    setInv(e, {}); setP(e, "prog", 0);
  }
  player.onScreenDisplay.setActionBar(status(e));
}
try {
  const startup = system.beforeEvents?.startup ?? world.beforeEvents?.worldInitialize;
  startup?.subscribe((ev) => ev.blockComponentRegistry.registerCustomComponent("oritech:machine", {
    onPlayerInteract: (a) => { const b = a.block, p = a.player; system.run(() => handleInteract(b, p)); },
  }));
} catch (err) { console.warn("oritech: custom component indisponível, usando fallback", err); }
world.afterEvents.playerInteractWithBlock.subscribe(({ block, player, isFirstEvent }) => { if (isFirstEvent) handleInteract(block, player); });

// ---------------- reator nuclear (multibloco) ----------------
// Estado de cada reator vive numa entidade invisível "oritech:nuclear_reactor" (no bloco controlador):
//   rs = estrutura escaneada (JSON), rx = estado (calor, combustível, resfriador...), energy = RF armazenado.
const RXR = new Map();                 // entity.id -> { e, dim, s, st, dirty, lit }
const RX_ENT = "oritech:nuclear_reactor";
const rxIsPort = (t) => t === RX.ID.fuelPort || t === RX.ID.coolPort;
const rxConnects = (fam, t) => (fam === "energy" && t === RX.ID.energyPort) || (fam === "item" && rxIsPort(t));
const fmtSec = (v) => (Number.isFinite(v) ? `${Math.round(v)}s` : "—");

function rxLoad(e, dim) {
  let r = RXR.get(e.id);
  if (r) { r.e = e; r.dim = dim; return r; }
  let s;
  try { s = JSON.parse(getP(e, "rs", "")); } catch { return null; }
  if (!s || !s.mn) return null;
  r = { e, dim, s, st: RX.unpackState(s, getP(e, "rx", "{}")), dirty: false, lit: new Map() };
  RXR.set(e.id, r);
  return r;
}
function rxAt(dim, x, y, z) {
  for (const r of RXR.values()) if (r.dim.id === dim.id && RX.inBox(r.s, x, y, z)) return r;
  return undefined;
}
const rxCol = (s, x, z) => (x - s.mn[0] - 1) + (z - s.mn[2] - 1) * s.iw;
function rxSave(r) {
  try { setP(r.e, "rx", RX.packState(r.st)); } catch (err) { console.warn("oritech reator: estado grande demais p/ salvar", err); }
}
function rxInsert(e, id, amount, col) {
  const r = RXR.get(e.id);
  if (!r) return { n: 0 };
  const n = RX.FUEL[id] ? RX.insertFuel(r.s, r.st, id, amount, col) : RX.COOLANT[id] ? RX.insertCoolant(r.s, r.st, id, amount, col) : 0;
  if (n > 0) rxSave(r);
  return { n };
}

function rxStatus(r) {
  const sm = RX.summary(r.s, r.st), en = getP(r.e, "energy");
  const col = sm.hot >= RX.CFG.MAX_HEAT * RX.CFG.WARN ? "§c" : sm.hot >= RX.CFG.MAX_HEAT / 2 ? "§e" : "§a";
  let s = `§6${NAMES.nuclear_reactor}§r`;
  s += `\n§fEnergia: §e${Math.floor(en).toLocaleString()} §7/ ${RX.CFG.MAX_ENERGY.toLocaleString()} RF`;
  s += `\n§fTemperatura: ${col}${Math.round(sm.hot)}°C §7/ ${RX.CFG.MAX_HEAT}°C`;
  s += `\n§fCombustível: §a${sm.hasFuelPort ? fmtSec(sm.fuelSec) : "—"} §7(${sm.pellets} pelotas, ${sm.rodsOn}/${sm.rodsTotal} hastes ativas)`;
  s += `\n§fResfriador: §b${sm.hasCoolPort ? fmtSec(sm.coolSec) : "—"} §7(${sm.ice} gelo)`;
  if (r.dirty) s += "\n§eEstrutura alterada — clique no controlador para atualizar";
  else if (sm.cooldown > 0) s += `\n§6Modo seguro: resfriando ${fmtSec(sm.cooldown / 20)}`;
  else if (sm.unstable > 0) s += `\n§c§lPERIGO! §r§cExplosão em ${fmtSec((RX.CFG.MAX_UNSTABLE_TICKS - sm.unstable) / 20)}`;
  return s;
}

const RX_ERR = {
  unloaded: () => "área não carregada — chegue mais perto",
  big: () => "estrutura grande demais",
  small: (e) => `casca pequena demais (${e.dim.join("x")}); mínimo 3x3x3`,
  size: (e) => `tamanho máximo é ${e.max} blocos por lado (achei ${e.dim.join("x")})`,
  gap: (e) => `falta um bloco de parede em ${e.pos.join(" ")}`,
  edge: (e) => `as arestas só podem ser Parede de Reator (${e.pos.join(" ")})`,
  controllers: (e) => `precisa de exatamente 1 controlador (achei ${e.n})`,
  badport: (e) => `porta de combustível/resfriador só no teto, fora das arestas (${e.pos.join(" ")})`,
  portbelow: (e) => `precisa de ${e.need} embaixo da porta em ${e.pos.join(" ")}`,
  invalid: (e) => `bloco inválido dentro do reator em ${e.pos.join(" ")} (${e.type.replace("minecraft:", "")})`,
  layer: (e) => `o interior precisa ser igual em todas as camadas (diferença em ${e.pos.join(" ")})`,
};

// camada de "acesa" nas hastes (troca o modelo)
function rxLit(r, lit) {
  const { dim, s } = r, ys = [];
  for (let y = s.mn[1] + 1; y < s.mx[1]; y++) ys.push(y);
  for (let i = 0; i < s.grid.length; i++) {
    const c = s.grid[i];
    if (c !== "a" && c !== "b" && c !== "c") continue;
    const on = !!lit[i];
    if (r.lit.get(i) === on) continue;
    const x = s.mn[0] + 1 + (i % s.iw), z = s.mn[2] + 1 + Math.floor(i / s.iw);
    let ok = true;
    for (const y of ys) {
      const b = dim.getBlock({ x, y, z });
      if (!b) { ok = false; continue; }
      try { if (b.permutation.getState("oritech:lit") !== on) b.setPermutation(b.permutation.withState("oritech:lit", on)); } catch { /* ignora */ }
    }
    if (ok) r.lit.set(i, on);
  }
}

function rxDismantle(r, drop) {
  const { dim, s } = r;
  try { rxLit(r, new Array(s.grid.length).fill(false)); } catch { /* ignora */ }
  if (drop) for (const [id, n] of RX.takeItems(r.st)) spawnStacks(dim, { x: s.ctrl.x + 0.5, y: s.ctrl.y + 1, z: s.ctrl.z + 0.5 }, id, n);
  RXR.delete(r.e.id);
  try { r.e.remove(); } catch { /* ignora */ }
}

function rxMeltdown(r) {
  const { dim, s } = r;
  const center = { x: (s.mn[0] + s.mx[0]) / 2 + 0.5, y: (s.mn[1] + s.mx[1]) / 2 + 0.5, z: (s.mn[2] + s.mx[2]) / 2 + 0.5 };
  const radius = Math.min(24, 6 + Math.sqrt(RX.meltPower(s)) * 2.5);
  for (const p of world.getAllPlayers()) {
    if (p.dimension.id !== dim.id) continue;
    const d = Math.hypot(p.location.x - center.x, p.location.z - center.z);
    if (d < 96) p.onScreenDisplay.setActionBar("§4§lMELTDOWN! §r§cO reator explodiu!");
  }
  RXR.delete(r.e.id);
  try { r.e.remove(); } catch { /* ignora */ }
  try { dim.createExplosion(center, radius, { breaksBlocks: true, causesFire: true }); }
  catch (err) { try { dim.createExplosion(center, 10, { breaksBlocks: true, causesFire: true }); } catch { console.warn("oritech meltdown:", err); } }
}

// puxa pelotas/gelo de baús ligados às portas (direto ou por canos de itens)
function rxPull(r) {
  const { dim, s, st } = r;
  const ports = [...s.fp.map((c) => [c, true]), ...s.cp.map((c) => [c, false])];
  for (const [c, fuel] of ports) {
    const net = pipeNet(dim, [RX.colPos(s, c)], "item");
    for (const inv of net.invs.values()) {
      const cont = inv.getComponent("minecraft:inventory")?.container;
      if (!cont) continue;
      let moved = false;
      for (let sl = 0; sl < cont.size && !moved; sl++) {
        const it = cont.getItem(sl);
        if (!it || !RX.accepts(it.typeId)) continue;
        const k = Math.min(it.amount, 16);
        const n = fuel ? RX.insertFuel(s, st, it.typeId, k, c) : RX.insertCoolant(s, st, it.typeId, k, c);
        if (n > 0) { if (it.amount > n) { it.amount -= n; cont.setItem(sl, it); } else cont.setItem(sl, undefined); moved = true; }
      }
      if (moved) break;
    }
  }
}

// ---------------- GUI do reator: 3 barras (energia, temperatura, combustível) no container da entidade ----------------
// slot 0 = energia · 1 = temperatura · 2 = combustível (verde) — travados, só visuais (itens "oritech:ui_<tipo>_NN")
const GR_TITLE = "\u00a7r\u00a74\u00a7r";   // invisível: ativa a tela customizada (chest_screen)
function guiReactorSync(r) {
  const c = guiContainer(r.e);
  if (!c) return;
  if (r.e.nameTag !== GR_TITLE) r.e.nameTag = GR_TITLE;
  const sm = RX.summary(r.s, r.st), energy = getP(r.e, "energy"), max = RX.CFG.MAX_HEAT;
  const tcol = sm.hot >= max * RX.CFG.WARN ? "§c" : sm.hot >= max / 2 ? "§e" : "§a";
  guiPaintBar(c, 0, "energy", energy / RX.CFG.MAX_ENERGY, "§6Energia", [`§f${fmtRF(energy)} / ${fmtRF(RX.CFG.MAX_ENERGY)} RF`]);
  guiPaintBar(c, 1, "temp", Math.min(1, sm.hot / max), "§cTemperatura", [`${tcol}${Math.round(sm.hot)}°C §7/ ${max}°C`,
    sm.cooldown > 0 ? `§6Modo seguro: ${fmtSec(sm.cooldown / 20)}` : sm.unstable > 0 ? `§cInstável! Explosão em ${fmtSec((RX.CFG.MAX_UNSTABLE_TICKS - sm.unstable) / 20)}` : "§7Estável"]);
  guiPaintBar(c, 2, "fuel", sm.fuelMax > 0 ? sm.fuelUnits / sm.fuelMax : 0, "§aCombustível",
    [sm.hasFuelPort ? `§f${fmtSec(sm.fuelSec)} restantes` : "§7Sem porta de combustível", `§7${sm.pellets} pelotas · ${sm.rodsOn}/${sm.rodsTotal} hastes ativas`]);
}

function tickReactor(m) {
  const r = RXR.get(m.e.id);
  if (!r) return;
  const { e, dim, s, st } = r;
  if (stepN % 2 === 0) rxPull(r);
  const res = RX.step(s, st, STEP, r.dirty);
  setP(e, "energy", Math.min(RX.CFG.MAX_ENERGY, getP(e, "energy") + res.gen));
  try { rxLit(r, res.lit); } catch (err) { console.warn("oritech reator (luz):", err); }
  if (res.melt) { rxMeltdown(r); return; }
  const c = { x: s.ctrl.x + 0.5, y: s.ctrl.y + 0.5, z: s.ctrl.z + 0.5 };
  if (res.warn) {
    dim.playSound("note.pling", c, { volume: 2, pitch: 0.5 });
    for (const p of dim.getPlayers({ location: c, maxDistance: 32 }))
      p.onScreenDisplay.setActionBar(`§c§lALERTA! §r§cReator superaquecendo: ${Math.round(res.hotAny)}°C`);
  } else if (res.active > 0 && Math.random() < 0.25) dim.playSound("random.fizz", c, { volume: 0.3, pitch: 0.6 });
  if (res.safeStop) for (const p of dim.getPlayers({ location: c, maxDistance: 48 })) p.onScreenDisplay.setActionBar("§6Reator em modo seguro: desligado para resfriar");
  rxSave(r);
  try { guiReactorSync(r); } catch (err) { console.warn("oritech reator (GUI):", err); }
}

// escaneia a estrutura (em partes, p/ não travar) e monta/atualiza o reator
const assembling = new Set();
function rxAssemble(dim, cb, player) {
  const pos = { x: cb.x, y: cb.y, z: cb.z }, k = key(dim, pos.x, pos.y, pos.z);
  if (assembling.has(k)) return;
  assembling.add(k);
  const getType = (x, y, z) => { try { const b = dim.getBlock({ x, y, z }); return b ? b.typeId : undefined; } catch { return undefined; } };
  const gen = RX.scanGen(getType, pos);
  player.onScreenDisplay.setActionBar("§bEscaneando o reator...");
  system.runJob((function* () {
    let res;
    try { while (!(res = gen.next()).done) yield; } catch (err) { assembling.delete(k); console.warn("oritech scan:", err); return; }
    assembling.delete(k);
    try { rxFinish(dim, pos, player, res.value); } catch (err) { console.warn("oritech reator:", err); }
  })());
}
function rxFinish(dim, pos, player, res) {
  const cb = dim.getBlock(pos);
  if (!cb || cb.typeId !== RX.ID.controller) return;
  let r = [...RXR.values()].find((x) => x.dim.id === dim.id && same(x.s.ctrl, pos));
  if (!r) {   // entidade já existe mas ainda não foi carregada no registro?
    const near = dim.getEntities({ families: ["oritech_reactor"], location: { x: pos.x + 0.5, y: pos.y, z: pos.z + 0.5 }, maxDistance: 2 })
      .find((e) => getP(e, "ax", -1) === pos.x && getP(e, "ay", -1e9) === pos.y && getP(e, "az", -1) === pos.z);
    if (near) r = rxLoad(near, dim);
  }
  if (!res.ok) {
    if (r) { r.dirty = true; }
    const f = RX_ERR[res.err.kind];
    player.onScreenDisplay.setActionBar(`§cReator incompleto: §f${f ? f(res.err) : res.err.kind}`);
    return;
  }
  const s = res.s;
  if (r) {
    const { st, lost } = RX.migrate(r.s, r.st, s);
    for (const [id, n] of lost) spawnStacks(dim, { x: pos.x + 0.5, y: pos.y + 1, z: pos.z + 0.5 }, id, n);
    r.s = s; r.st = st; r.dirty = false; r.lit = new Map();
  } else {
    const e = dim.spawnEntity(RX_ENT, { x: pos.x + 0.5, y: pos.y, z: pos.z + 0.5 });
    setP(e, "ax", pos.x); setP(e, "ay", pos.y); setP(e, "az", pos.z); setP(e, "energy", 0);
    r = { e, dim, s, st: RX.newState(s), dirty: false, lit: new Map() };
    RXR.set(e.id, r);
    dim.playSound("random.anvil_use", { x: pos.x + 0.5, y: pos.y + 0.5, z: pos.z + 0.5 }, { volume: 0.6, pitch: 1.3 });
  }
  setP(r.e, "rs", JSON.stringify(s));
  rxSave(r);
  refreshAround(dim, pos.x, pos.y, pos.z);
  for (const p of s.ep) refreshAround(dim, p.x, p.y, p.z);
  ctmFlood(dim, s.ctrl);
  player.onScreenDisplay.setActionBar(`§aReator montado §7(${s.iw}x${s.ih}x${s.id} por dentro, ${s.rods} hastes, ${s.fp.length} portas de combustível, ${s.cp.length} de resfriador, ${s.ep.length} de energia)`);
}

function rxInteract(block, player) {
  const dim = block.dimension, t = block.typeId;
  const cont = player.getComponent("minecraft:inventory").container, slot = player.selectedSlotIndex, held = cont.getItem(slot);
  const creative = player.getGameMode() === GameMode.Creative;
  const r = rxAt(dim, block.x, block.y, block.z);
  const port = rxIsPort(t);
  const col = r && port ? rxCol(r.s, block.x, block.z) : undefined;
  if (held && r && RX.accepts(held.typeId) && (port || t === RX.ID.controller)) {
    const n = rxInsert(r.e, held.typeId, held.amount, col).n;
    if (n > 0) {
      if (!creative) { if (held.amount > n) { held.amount -= n; cont.setItem(slot, held); } else cont.setItem(slot, undefined); }
      dim.playSound("random.click", block.center(), { volume: 0.6 });
    } else player.onScreenDisplay.setActionBar("§eEssa porta não aceita mais itens (ou não é a porta certa)");
    if (n > 0) player.onScreenDisplay.setActionBar(rxStatus(r));
    return;
  }
  if (r && port && !held && player.isSneaking) {
    for (const [id, n] of RX.takeItems(r.st, col)) giveItem(player, id, n);
    rxSave(r);
    player.onScreenDisplay.setActionBar(rxStatus(r));
    return;
  }
  if (t === RX.ID.controller && !(held && RX.isReactorBlock(held.typeId))) { rxAssemble(dim, block, player); return; }
  if (r) player.onScreenDisplay.setActionBar(rxStatus(r));
}
function rxOnPlace(dim, block, player) {
  const r = rxAt(dim, block.x, block.y, block.z);
  if (r) { r.dirty = true; player?.onScreenDisplay.setActionBar("§eEstrutura do reator alterada: clique no controlador para atualizar"); }
  system.runTimeout(() => refreshAround(dim, block.x, block.y, block.z), 1);
}
function rxOnBreak(dim, pos, t, player) {
  if (t === RX.ID.controller) {
    const r = [...RXR.values()].find((x) => x.dim.id === dim.id && same(x.s.ctrl, pos));
    if (r) rxDismantle(r, true);
  } else {
    const r = rxAt(dim, pos.x, pos.y, pos.z);
    if (r) { r.dirty = true; player?.onScreenDisplay.setActionBar("§eEstrutura do reator alterada: clique no controlador para atualizar"); }
  }
  system.runTimeout(() => refreshAround(dim, pos.x, pos.y, pos.z), 1);
}

// ---------------- rede de energia ----------------
function runNetworks(list) {
  const occ = new Map();
  list.forEach((m, i) => m.cells.forEach((c) => occ.set(key(m.dim, c.x, c.y, c.z), i)));
  const parent = list.map((_, i) => i);
  const find = (i) => { while (parent[i] !== i) { parent[i] = parent[parent[i]]; i = parent[i]; } return i; };
  const union = (a, b) => { parent[find(a)] = find(b); };
  const cableRep = new Map(), cableCache = new Map(), superIdx = new Set();
  const cableAt = (dim, x, y, z) => {
    const k = key(dim, x, y, z);
    if (!cableCache.has(k)) { const b = dim.getBlock({ x, y, z }); cableCache.set(k, b && PIPE_FAM[b.typeId] === "energy" ? b.typeId : null); }
    return cableCache.get(k);
  };
  list.forEach((m, i) => {
    for (const c of m.cells) for (const [dx, dy, dz] of DIRS) {
      const x = c.x + dx, y = c.y + dy, z = c.z + dz, k = key(m.dim, x, y, z);
      if (occ.has(k)) { union(i, occ.get(k)); continue; }
      if (cableRep.has(k)) { union(i, cableRep.get(k)); if (SUPER.has(cableAt(m.dim, x, y, z))) superIdx.add(i); continue; }
      const ty = cableAt(m.dim, x, y, z);
      if (!ty) continue;
      if (SUPER.has(ty)) superIdx.add(i);
      const stack = [[x, y, z]]; cableRep.set(k, i); let guard = 0;
      while (stack.length && guard++ < 600) {
        const [cx, cy, cz] = stack.pop();
        for (const [ax, ay, az] of DIRS) {
          const nx = cx + ax, ny = cy + ay, nz = cz + az, nk = key(m.dim, nx, ny, nz);
          if (occ.has(nk)) { union(i, occ.get(nk)); continue; }
          if (cableRep.has(nk)) continue;
          const nt = cableAt(m.dim, nx, ny, nz);
          if (nt) { if (SUPER.has(nt)) superIdx.add(i); cableRep.set(nk, i); stack.push([nx, ny, nz]); }
        }
      }
    }
  });
  const superRoots = new Set([...superIdx].map(find));
  const groups = new Map();
  list.forEach((m, i) => { const r = find(i); if (!groups.has(r)) groups.set(r, []); groups.get(r).push(m); });
  const capOf = (m) => (MACH[m.id] ?? SPECIAL[m.id] ?? STORE[m.id] ?? GEN[m.id]).cap;
  const outCap = (m) => (m.id === "nuclear_reactor" ? m.cells.length * RX.CFG.PORT_OUT * STEP : Infinity);   // 25.000 RF/t por porta de energia
  const give = (m) => Math.min(getP(m.e, "energy"), outCap(m));
  const transfer = (prods, takers, limit) => {
    const avail = prods.reduce((s, m) => s + give(m), 0);
    const need = takers.reduce((s, m) => s + Math.max(0, capOf(m) - getP(m.e, "energy")), 0);
    const flow = Math.min(avail, need, limit);
    if (flow <= 0) return;
    prods.forEach((m) => setP(m.e, "energy", getP(m.e, "energy") - (flow * give(m)) / avail));
    takers.forEach((m) => { const n = Math.max(0, capOf(m) - getP(m.e, "energy")); setP(m.e, "energy", getP(m.e, "energy") + (flow * n) / need); });
  };
  for (const [root, members] of groups) {
    if (members.length < 2) continue;
    const limit = superRoots.has(root) ? 1e9 : FLOW;
    const gens = members.filter((m) => GEN[m.id] && getP(m.e, "energy") > 0);
    const stores = members.filter((m) => STORE[m.id] && !STORE[m.id].creative && !STORE[m.id].src);
    const sources = members.filter((m) => STORE[m.id] && getP(m.e, "energy") > 0);
    const cons = members.filter((m) => (MACH[m.id] || SPECIAL[m.id]) && getP(m.e, "energy") < capOf(m));
    if (gens.length && cons.length) transfer(gens, cons, limit);
    const gens2 = gens.filter((m) => getP(m.e, "energy") > 0);
    if (gens2.length && stores.length) transfer(gens2, stores, limit);
    if (sources.length && cons.length) transfer(sources, cons.filter((m) => getP(m.e, "energy") < capOf(m)), limit);
  }
}

function setVar(e, v) {
  if (getP(e, "vs", 0) === v) return;
  setP(e, "vs", v);
  e.triggerEvent(v === 1 ? "oritech:set_working" : v === 3 ? "oritech:set_folded" : "oritech:set_idle");
}
const setWorking = (e, on) => setVar(e, on ? 1 : 0);

// ---------------- partículas das máquinas ----------------
// Efeitos aproximados aos usados pelo Oritech Java 1.21.1.
// Quando o Java usa uma partícula específica, usamos o equivalente Bedrock mais próximo.
const MACHINE_PARTICLES = {
  steam_engine: ["minecraft:cloud"],
  powered_furnace: ["minecraft:lava_particle"],
  pulverizer: ["minecraft:basic_smoke_particle"],
  assembler: ["minecraft:enchanting_table_particle"],
  fragment_forge: ["minecraft:basic_smoke_particle"],
  cooler: ["minecraft:snowflake_particle"],
  refinery: ["minecraft:snowflake_particle"],
  tainted_refinery: ["minecraft:soul_particle"],
  enchanter: ["minecraft:enchanting_table_particle"],
  enchantment_catalyst: ["minecraft:lava_particle", "minecraft:villager_happy"],
  deep_drill: ["minecraft:lava_particle"],
  pump: ["minecraft:water_drip_particle"],
  laser_arm: ["minecraft:sonic_explosion"],
  // Máquinas sem um efeito próprio identificado no Java recebem uma fumaça discreta.
  basic_generator: ["minecraft:basic_smoke_particle"],
  fuel_generator: ["minecraft:basic_smoke_particle"],
  bio_generator: ["minecraft:basic_smoke_particle"],
  lava_generator: ["minecraft:lava_particle"],
  foundry: ["minecraft:basic_smoke_particle"],
  centrifuge: ["minecraft:basic_smoke_particle"],
  atomic_forge: ["minecraft:basic_smoke_particle"],
  treefeller: ["minecraft:basic_smoke_particle"],
  pipe_booster: ["minecraft:basic_smoke_particle"],
  drone_port: ["minecraft:basic_smoke_particle"]
};
function machineFx(m) {
  const ids = MACHINE_PARTICLES[m.id];
  if (!ids || !m.e) return;
  const cfg = MACHINES[m.id] ?? { ny: 1 };
  const p = {
    x: m.base.x + 0.5,
    y: m.base.y + Math.max(0.9, (cfg.ny ?? 1) - 0.1),
    z: m.base.z + 0.5
  };
  try {
    // Efeitos leves para evitar spam/lag: 1 partícula por atualização,
    // ou duas quando a máquina estiver trabalhando mais intensamente.
    const id = ids[Math.floor(Math.random() * ids.length)];
    if (m.id === "steam_engine") {
      // O Java usa ParticleTypes.CLOUD: vapor branco, na frente do motor.
      const face = getP(m.e, "sf", 0);
      const off = face === 0 ? {x:0,z:-0.5} : face === 1 ? {x:0.5,z:0} : face === 2 ? {x:0,z:0.5} : {x:-0.5,z:0};
      if (Math.random() < 0.9) m.dim.spawnParticle("minecraft:cloud", { x: m.base.x + 0.5 + off.x, y: m.base.y + 1.15, z: m.base.z + 0.5 + off.z });
      if (Math.random() < 0.55) m.dim.spawnParticle("minecraft:cloud", { x: m.base.x + 0.5 + off.x + (Math.random()-0.5)*0.18, y: m.base.y + 1.28, z: m.base.z + 0.5 + off.z + (Math.random()-0.5)*0.18 });
    } else {
      m.dim.spawnParticle(id, p);
      m.dim.spawnParticle(id, { x:p.x+(Math.random()-0.5)*0.18, y:p.y+0.12, z:p.z+(Math.random()-0.5)*0.18 });
    }
  } catch (err) { /* alguns nomes de partículas podem variar entre versões */ }
}

// ---------------- GUI do gerador básico (container da entidade + item-barra, como o UtilityCraft) ----------------
// slot 0 = item que desenha a barra de energia (travado, só visual); slot 1 = combustível (slot real, como o GuiSlot(0,80,21) do Java)
const GUI_GEN = new Set(["basic_generator"]);
const GUI_TITLE = "\u00a7r\u00a70\u00a7r";   // invisível: só serve para ativar a tela customizada
const GUI_ARROW_SLOT = 2, GUI_BAR_SLOT = 0, GUI_FUEL_SLOT = 1, GUI_BAR_STEPS = 48;
function guiContainer(e) { try { return e.getComponent("minecraft:inventory")?.container; } catch { return undefined; } }
function fmtRF(n) {
  const f = (v, u) => (v.toFixed(1) + u).replace(".0", "");
  return n >= 1e6 ? f(n / 1e6, "M") : n >= 1e3 ? f(n / 1e3, "k") : String(Math.floor(n));
}
// consome 1 combustível do slot quando o gerador não está queimando (como o Java)
function guiFeed(e, g) {
  const c = guiContainer(e);
  if (!c) return;
  if (e.nameTag !== GUI_TITLE) e.nameTag = GUI_TITLE;       // o nome fixo ativa a tela customizada (chest_screen)
  if (getP(e, "burn") > 0 || getP(e, "energy") >= g.cap) return;
  const it = c.getItem(GUI_FUEL_SLOT);
  if (!it) return;
  const t = g.fuels[it.typeId];
  if (!t) return;
  if (it.amount > 1) { it.amount -= 1; c.setItem(GUI_FUEL_SLOT, it); } else c.setItem(GUI_FUEL_SLOT, undefined);
  setP(e, "burn", getP(e, "burn") + t);
}
// pinta a barra de energia (slot barSlot) e a seta de progresso (slot arrowSlot) no container da entidade
function guiPaint(c, barSlot, arrowSlot, energy, cap, aidx) {
  const idx = Math.max(0, Math.min(GUI_BAR_STEPS, Math.round((energy / cap) * GUI_BAR_STEPS)));
  const id = "oritech:ui_energy_" + String(idx).padStart(2, "0");
  const name = "§6Energia";
  const line = `§f${fmtRF(energy)} / ${fmtRF(cap)} RF`;
  const aid = "oritech:ui_arrow_" + String(aidx).padStart(2, "0");
  const acur = c.getItem(arrowSlot);
  if (!acur || acur.typeId !== aid) {
    const arrow = new ItemStack(aid, 1);
    arrow.lockMode = ItemLockMode.slot;
    arrow.keepOnDeath = true;
    c.setItem(arrowSlot, arrow);
  }
  const cur = c.getItem(barSlot);
  if (cur && cur.typeId === id && cur.nameTag === name && cur.getLore()[0] === line) return;
  const bar = new ItemStack(id, 1);
  bar.nameTag = name;
  bar.setLore([line]);
  bar.lockMode = ItemLockMode.slot;
  bar.keepOnDeath = true;
  c.setItem(barSlot, bar);
}
// atualiza o item-barra (ícone = nível, nome/lore = texto ao passar o mouse)
function guiSync(e, g) {
  const c = guiContainer(e);
  if (!c) return;
  const energy = getP(e, "energy");
  // seta de progresso (igual ao Java: enche conforme o combustível queima)
  const burn = getP(e, "burn"), bmax = burn > 0 ? Math.max(getP(e, "bmax"), burn) : 0;
  if (getP(e, "bmax") !== bmax) setP(e, "bmax", bmax);
  const aidx = bmax > 0 ? Math.max(0, Math.min(29, Math.round(((bmax - burn) / bmax) * 29))) : 0;
  guiPaint(c, GUI_BAR_SLOT, GUI_ARROW_SLOT, energy, g.cap, aidx);
}

// ---------------- GUI do motor a vapor (layout do Java: barra de energia + tanques de água e vapor) ----------------
// container da entidade: 0 = barra de energia · 1 = barra de água · 2 = barra de vapor (os três travados, só visuais)
//                        3 = combustível (slot real) · 4 = balde de água (slot real: vira água no tanque e devolve o balde vazio)
// Mesma lógica da barra de energia: um item "oritech:ui_<tipo>_NN" (NN = 00..48) desenhado no slot, com nome/lore como dica.
const GUI_STEAM = new Set(["steam_engine"]);
const GS_ENERGY = 0, GS_WATER = 1, GS_STEAM = 2, GS_FUEL = 3, GS_BUCKET = 4, GS_TANK = 24000;
const GS_TITLE = "\u00a7r\u00a73\u00a7r";   // invisível: ativa a tela customizada (chest_screen)
function guiPaintBar(c, slot, kind, ratio, name, lines) {
  const idx = Math.max(0, Math.min(GUI_BAR_STEPS, Math.round(ratio * GUI_BAR_STEPS)));
  const id = `oritech:ui_${kind}_${String(idx).padStart(2, "0")}`;
  const cur = c.getItem(slot);
  if (cur && cur.typeId === id && cur.nameTag === name) {
    const lo = cur.getLore();
    if (lo.length === lines.length && lo.every((l, i) => l === lines[i])) return;
  }
  const bar = new ItemStack(id, 1);
  bar.nameTag = name;
  bar.setLore(lines);
  bar.lockMode = ItemLockMode.slot;
  bar.keepOnDeath = true;
  c.setItem(slot, bar);
}
// slot do balde: balde de água cheio vira 4000 de água no tanque e o slot passa a ter o balde vazio
function guiSteamBucket(e, g, c) {
  const it = c.getItem(GS_BUCKET);
  if (!it || !g.water || !g.water[it.typeId]) return;
  const t = g.water[it.typeId], wt = getP(e, "water");
  if (wt + t > GS_TANK) return;
  setP(e, "water", wt + t);
  if (it.amount > 1) { it.amount -= 1; c.setItem(GS_BUCKET, it); } else c.setItem(GS_BUCKET, new ItemStack(g.returns ?? "minecraft:bucket", 1));
}
// consome 1 combustível do slot quando o motor não está queimando (igual ao gerador básico)
function guiSteamFeed(e, g) {
  const c = guiContainer(e);
  if (!c) return;
  if (e.nameTag !== GS_TITLE) e.nameTag = GS_TITLE;
  guiSteamBucket(e, g, c);
  if (getP(e, "burn") > 0 || getP(e, "energy") >= g.cap) return;
  const it = c.getItem(GS_FUEL);
  if (!it) return;
  const t = g.fuels[it.typeId];
  if (!t) return;
  if (it.amount > 1) { it.amount -= 1; c.setItem(GS_FUEL, it); } else c.setItem(GS_FUEL, undefined);
  setP(e, "burn", getP(e, "burn") + t);
}
function guiSteamSync(e, g) {
  const c = guiContainer(e);
  if (!c) return;
  const energy = getP(e, "energy"), burn = getP(e, "burn"), water = getP(e, "water");
  const on = burn > 0 && water > 0 && energy < g.cap;
  const steam = Math.min(burn, water);   // vapor disponível: precisa de calor (combustível) e de água
  guiPaintBar(c, GS_ENERGY, "energy", energy / g.cap, "§6Energia",
    [`§f${fmtRF(energy)} / ${fmtRF(g.cap)} RF`, on ? `§a+${g.rf} RF/t` : "§7Parado"]);
  guiPaintBar(c, GS_WATER, "water", water / GS_TANK, "§bÁgua",
    [`§f${Math.round(water / 20)}s / ${Math.round(GS_TANK / 20)}s`, `§7${(water / 4000).toFixed(1)} baldes`]);
  guiPaintBar(c, GS_STEAM, "steam", steam / GS_TANK, "§fVapor",
    [`§f${Math.round(steam / 20)}s / ${Math.round(GS_TANK / 20)}s`, on ? `§aProduzindo (${Math.round(Math.max(0.1, Math.min(1, water / 4000)) * 100)}% da velocidade)` : "§7Sem vapor"]);
}

// ---------------- GUI das máquinas (layout do Java) ----------------
// fornalha elétrica: entrada 56,38 · saída 117,38 | pulverizador: entrada 56,38 · saídas 117,38 e 135,38 | energia 8,24 · seta 80,35
// container da entidade: 0 = barra de energia (travado) · 1 = entrada (real) · 2.. = saídas (reais) · último = seta de progresso (travado)
// A lógica da máquina continua usando o "inv" (dutos, itens soltos e clique no bloco); a cada passo os slots são
// puxados para o inv antes do tick e o item da receita volta para o slot depois, então tudo fica sincronizado.
const GUI_MACH = {
  powered_furnace: { title: "\u00a7r\u00a71\u00a7r", outs: 1 },   // título invisível: ativa a tela customizada (chest_screen)
  pulverizer: { title: "\u00a7r\u00a72\u00a7r", outs: 2 },
};
const GM_BAR = 0, GM_IN = 1;
const gmOutSlots = (cfg) => Array.from({ length: cfg.outs }, (_, i) => 2 + i);
function guiMachPre(e, def) {
  const c = guiContainer(e), cfg = GUI_MACH[idOf(e)];
  if (!c || !cfg) return;
  if (e.nameTag !== cfg.title) e.nameTag = cfg.title;
  const inv = getInv(e);
  let changed = false;
  // slots de saída: item de entrada colocado ali (ex.: shift+clique com o slot de entrada cheio) vira entrada
  for (const sl of gmOutSlots(cfg)) {
    const out = c.getItem(sl), key = "gout" + sl;
    if (!out) { if (getP(e, key, "") !== "") setP(e, key, ""); }
    else if (out.typeId !== getP(e, key, "") && def.accepts.has(out.typeId)) {
      inv[out.typeId] = (inv[out.typeId] ?? 0) + out.amount;
      c.setItem(sl, undefined);
      changed = true;
    }
  }
  // slot de entrada -> inv (só o que a máquina aceita; o resto fica no slot)
  const it = c.getItem(GM_IN);
  if (it && def.accepts.has(it.typeId)) {
    inv[it.typeId] = (inv[it.typeId] ?? 0) + it.amount;
    c.setItem(GM_IN, undefined);
    changed = true;
  }
  if (changed) setInv(e, inv);
}
function guiMachPost(e, def) {
  const c = guiContainer(e), cfg = GUI_MACH[idOf(e)];
  if (!c || !cfg) return;
  const inv = getInv(e);
  // devolve ao slot de entrada o item que a receita atual está usando (ou o primeiro item aceito)
  if (!c.getItem(GM_IN)) {
    const ri = getP(e, "rec", -1);
    let id = ri >= 0 ? Object.keys(def.recipes[ri].in)[0] : undefined;
    if (!id || !(inv[id] > 0)) id = Object.keys(inv).find((k) => inv[k] > 0);
    if (id) {
      const n = Math.min(inv[id], new ItemStack(id, 1).maxAmount);
      c.setItem(GM_IN, new ItemStack(id, n));
      inv[id] -= n;
      setInv(e, inv);
    }
  }
  // barra de energia + seta (progresso da receita atual)
  const ri = getP(e, "rec", -1), r = ri >= 0 ? def.recipes[ri] : undefined;
  const aidx = r ? Math.max(0, Math.min(29, Math.round((getP(e, "prog") / r.time) * 29))) : 0;
  guiPaint(c, GM_BAR, 2 + cfg.outs, getP(e, "energy"), def.cap, aidx);
}
// coloca o resultado nº k da receita no slot de saída k (ou em outro slot de saída livre); devolve quantos itens sobraram
function guiOutput(e, id, n, k = 0) {
  const c = guiContainer(e), cfg = GUI_MACH[idOf(e)];
  if (!c || !cfg) return n;
  const slots = gmOutSlots(cfg), order = [slots[Math.min(k, slots.length - 1)], ...slots.filter((x) => x !== slots[Math.min(k, slots.length - 1)])];
  for (const sl of order) {
    if (n <= 0) break;
    const cur = c.getItem(sl);
    if (!cur) {
      const q = Math.min(n, new ItemStack(id, 1).maxAmount);
      c.setItem(sl, new ItemStack(id, q));
      setP(e, "gout" + sl, id);
      n -= q;
    } else if (cur.typeId === id) {
      const q = Math.min(n, cur.maxAmount - cur.amount);
      if (q > 0) { cur.amount += q; c.setItem(sl, cur); setP(e, "gout" + sl, id); n -= q; }
    }
  }
  return n;
}
function guiTakeAll(e, player) {
  const c = guiContainer(e), cfg = GUI_MACH[idOf(e)];
  if (!c || !cfg) return;
  for (const s of [GM_IN, ...gmOutSlots(cfg)]) {
    const it = c.getItem(s);
    if (it) { giveItem(player, it.typeId, it.amount); c.setItem(s, undefined); }
  }
}
function guiDropContents(e) {
  const c = guiContainer(e);
  if (!c) return;
  const loc = { x: e.location.x, y: e.location.y + 0.5, z: e.location.z };
  if (GUI_MACH[idOf(e)]) {
    for (const sl of [GM_IN, ...gmOutSlots(GUI_MACH[idOf(e)])]) { const it = c.getItem(sl); if (it) e.dimension.spawnItem(it, loc); }
    for (const [k, n] of Object.entries(getInv(e))) spawnStacks(e.dimension, loc, k, n);
    setInv(e, {});
    return;
  }
  if (idOf(e) === "laser_arm") {
    for (const sl of LASER_SLOTS) { const it = c.getItem(sl); if (it) e.dimension.spawnItem(it, loc); }
    return;
  }
  if (GUI_STEAM.has(idOf(e))) {
    for (const sl of [GS_FUEL, GS_BUCKET]) { const it = c.getItem(sl); if (it) e.dimension.spawnItem(it, loc); }
    return;
  }
  const it = c.getItem(GUI_FUEL_SLOT);
  if (it) e.dimension.spawnItem(it, loc);
}
// ---------------- GUI do Armazenamento de Energia Grande (barra de energia; Java: 20M RF, entrada/saída máx. 10.000 RF/t) ----------------
function guiStoreSync(e, st) {
  const c = guiContainer(e);
  if (!c) return;
  if (e.nameTag !== GL_TITLE) e.nameTag = GL_TITLE;
  const energy = getP(e, "energy");
  guiPaintBar(c, 0, "energy", energy / st.cap, "§6Energia", [`§f${fmtRF(energy)} / ${fmtRF(st.cap)} RF`, `§7Entrada/Saída máx.: ${st.io.toLocaleString("pt-BR")} RF/t`]);
}

// ---------------- Target Designator (igual ao Java: clique salva a posição do bloco; agachado + clique na torreta entrega o alvo) ----------------
const DESIG = "oritech:target_designator";
function desigApply(player, e) {
  const inv = player.getComponent("minecraft:inventory").container, it = inv.getItem(player.selectedSlotIndex);
  const s = it?.getDynamicProperty("oritech:tgt");
  if (it?.typeId !== DESIG || typeof s !== "string") { player.onScreenDisplay.setActionBar("§cNenhuma posição salva no designador"); return; }
  const [x, y, z] = s.split(",").map(Number);
  setP(e, "tx", x); setP(e, "ty", y); setP(e, "tz", z); setP(e, "hasT", 1); setP(e, "lprog", 0); setP(e, "lkey", "");
  player.onScreenDisplay.setActionBar("§aPosição salva na máquina");
  e.dimension.playSound("random.orb", e.location, { volume: 0.6 });
}
world.afterEvents.playerInteractWithBlock.subscribe(({ block, player, isFirstEvent }) => {
  try {
    if (!isFirstEvent) return;
    const inv = player.getComponent("minecraft:inventory").container, slot = player.selectedSlotIndex, it = inv.getItem(slot);
    if (!it || it.typeId !== DESIG) return;
    const e = isMachineBlockId(block.typeId) ? machineAt(block.dimension, block.x, block.y, block.z) : undefined;
    if (e && idOf(e) === "laser_arm" && player.isSneaking) { desigApply(player, e); return; }
    it.setDynamicProperty("oritech:tgt", `${block.x},${block.y},${block.z}`);
    it.setLore([`§7Alvo: [${block.x}, ${block.y}, ${block.z}]`]);
    inv.setItem(slot, it);
    player.onScreenDisplay.setActionBar("§bPosição armazenada");
  } catch (err) { console.warn("oritech designador:", err); }
});
world.beforeEvents.playerInteractWithEntity.subscribe((ev) => {   // a metade de baixo do bloco é a entidade (abre a GUI): agachado + designador entrega o alvo
  const t = ev.target, held = ev.itemStack, p = ev.player;
  if (!t || t.typeId !== "oritech:laser_arm" || !held || held.typeId !== DESIG || !p.isSneaking) return;
  ev.cancel = true;
  system.run(() => { try { if (t.isValid) desigApply(p, t); } catch (err) { console.warn("oritech designador:", err); } });
});

// tinta clicada direto na entidade (a metade de baixo do bloco abre a GUI): aplica a skin em vez de abrir
world.beforeEvents.playerInteractWithEntity.subscribe((ev) => {
  const t = ev.target, held = ev.itemStack, p = ev.player;
  if (!t || !["oritech:basic_generator", "oritech:steam_engine", "oritech:large_storage", "oritech:laser_arm"].includes(t.typeId) || !held || PAINTS[held.typeId] === undefined) return;
  ev.cancel = true;
  const skin = PAINTS[held.typeId], typeId = held.typeId;
  system.run(() => {
    try {
      if (!t.isValid) return;
      setSkin(t, skin);
      if (p.getGameMode() !== GameMode.Creative) {
        const inv = p.getComponent("minecraft:inventory").container, i = p.selectedSlotIndex, h = inv.getItem(i);
        if (h && h.typeId === typeId) { if (h.amount > 1) { h.amount -= 1; inv.setItem(i, h); } else inv.setItem(i, undefined); }
      }
      t.dimension.playSound("random.orb", t.location, { volume: 0.6 });
    } catch (err) { console.warn("oritech tinta:", err); }
  });
});

function tickGenerator(m, g) {
  const { e, dim, base } = m, cfg = MACHINES[m.id];
  const energy = getP(e, "energy");
  if (g.solar) {
    // rotação igual à do Java: getTimeOffset() = (int)(sin((x+z)/60)*100); hora ajustada = (dia + offset) % 24000;
    // alvo = (hora - 6000) / 6000 * 45°; o cliente suaviza com lerp 0.06 por frame e zera a base depois de 13000
    const adj = (world.getTimeOfDay() + Math.trunc(Math.sin((base.x + base.z) / 60) * 100)) % 24000;
    const ang = solarSign() * Math.round(((adj - 6000) / 6000) * 45 * 100) / 100;
    if (Math.abs((e.getProperty("oritech:sun_angle") ?? 0) - ang) > 0.01) e.setProperty("oritech:sun_angle", ang);
    const night = adj > 13000;
    if (e.getProperty("oritech:night") !== night) e.setProperty("oritech:night", night);
    const sf = solarYaw();
    if (getP(e, "sf", -1) !== sf) { e.triggerEvent("oritech:face_" + sf); setP(e, "sf", sf); }
    const day = world.getTimeOfDay() < 12000 && dim.id === "minecraft:overworld";
    const top = dim.getTopmostBlock({ x: base.x, z: base.z });
    const on = day && (!top || top.y <= base.y + cfg.ny - 1);
    if (on && energy < g.cap) setP(e, "energy", Math.min(g.cap, energy + g.rf * STEP));
    if (getP(e, "sun", -1) !== (on ? 1 : 0)) { setP(e, "sun", on ? 1 : 0); e.triggerEvent(on ? "oritech:set_idle" : "oritech:set_folded"); }
    return;
  }
  const burn = getP(e, "burn"), water = getP(e, "water");
  const on = burn > 0 && (!g.water || water > 0) && energy < g.cap;
  if (on) {
    setP(e, "burn", Math.max(0, burn - STEP));
    if (g.water) setP(e, "water", Math.max(0, water - STEP));
    setP(e, "energy", Math.min(g.cap, energy + g.rf * STEP));
    if (g.water) {
      // O Java acelera o motor conforme há mais fluido disponível.
      // Aqui usamos a água armazenada como o nível de vapor equivalente.
      const ratio = Math.max(0, Math.min(1, water / 4000));
      // O Java usa a fração do tanque para controlar a velocidade (até 10x).
      const speed = Math.max(0.1, ratio * 10);
      try { e.setProperty("oritech:steam_speed", speed); } catch {}
    }
  } else if (g.water) {
    try { e.setProperty("oritech:steam_speed", 0); } catch {}
  }
  setWorking(e, on);
  if (on) machineFx(m);
}

function tickMachine(m, def) {
  const { e, dim, base } = m, cfg = MACHINES[m.id];
  const inv = getInv(e);
  const ri = def.recipes.findIndex((r) => Object.entries(r.in).every(([k, n]) => (inv[k] ?? 0) >= n));
  if (getP(e, "rec", -1) !== ri) { setP(e, "rec", ri); setP(e, "prog", 0); }
  const energy = getP(e, "energy");
  const on = ri >= 0 && energy >= def.rf * STEP;
  if (on) {
    const r = def.recipes[ri];
    setP(e, "energy", energy - def.rf * STEP);
    let prog = getP(e, "prog") + STEP;
    if (prog >= r.time) {
      prog = 0;
      for (const [k, n] of Object.entries(r.in)) inv[k] -= n;
      setInv(e, inv);
      const zmax = Math.max(...cellsOf(e).map((c) => c.z));
      for (const [ok, [o, n]] of r.out.entries()) {
        let left = deliver(e, o, n);
        if (left > 0 && GUI_MACH[m.id]) left = guiOutput(e, o, left, ok);
        if (left > 0) spawnStacks(dim, { x: base.x + 0.5, y: base.y + 0.4, z: zmax + 1.7 }, o, left);
      }
      dim.playSound("random.pop", e.location, { volume: 0.5 });
    }
    setP(e, "prog", prog);
  }
  setVar(e, on ? 1 : def.catalyst && Object.keys(getInv(e)).length ? 3 : 0);
  if (on) machineFx(m);
}

function tickStore(m, st) { if (st.creative) setP(m.e, "energy", st.cap); }

function tickDrill(m, def) {
  const { e, dim, base } = m, cfg = MACHINES[m.id];
  const energy = getP(e, "energy"), on = energy >= def.rf * STEP;
  if (on) {
    setP(e, "energy", energy - def.rf * STEP);
    let prog = getP(e, "prog") + STEP;
    if (prog >= def.time) {
      prog = 0;
      const total = ORES.reduce((s, o) => s + o[1], 0);
      let r = Math.random() * total, pick = ORES[0][0];
      for (const [id, wt] of ORES) { r -= wt; if (r <= 0) { pick = id; break; } }
      const n = 1 + Math.floor(Math.random() * 2);
      const left = deliver(e, pick, n);
      if (left > 0) spawnStacks(dim, { x: base.x + 0.5, y: base.y + cfg.ny + 0.3, z: base.z + 0.5 }, pick, left);
      dim.playSound("random.anvil_land", e.location, { volume: 0.3, pitch: 1.6 });
    }
    setP(e, "prog", prog);
  }
  setWorking(e, on);
}

const LOGRE = /_(log|stem)$/;
function fellTree(dim, start) {
  const seen = new Set(), stack = [start], logs = []; let leaves = false;
  while (stack.length && logs.length < 120) {
    const b = stack.pop(), k = `${b.x},${b.y},${b.z}`;
    if (seen.has(k)) continue; seen.add(k); logs.push(b);
    for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) for (let dz = -1; dz <= 1; dz++) {
      if (!dx && !dy && !dz) continue;
      const n = dim.getBlock({ x: b.x + dx, y: b.y + dy, z: b.z + dz });
      if (!n) continue;
      if (LOGRE.test(n.typeId)) stack.push(n); else if (n.typeId.endsWith("leaves")) leaves = true;
    }
  }
  if (!leaves) return 0;                                  // sem folhas = construção do jogador, não corta
  for (const b of logs) dim.runCommand(`setblock ${b.x} ${b.y} ${b.z} air destroy`);
  return logs.length;
}
function tickCutter(m, def) {
  const { e, dim, base } = m;
  let energy = getP(e, "energy"), cool = getP(e, "cool");
  if (energy >= def.rf * STEP) {
    const R7 = 7, side = 2 * R7 + 1, total = side * side * 2, scan = getP(e, "scan");
    for (let i = 0; i < 30; i++) {
      const idx = (scan + i) % total, layer = Math.floor(idx / (side * side)), r = idx % (side * side);
      const b = dim.getBlock({ x: base.x - R7 + (r % side), y: base.y + layer, z: base.z - R7 + Math.floor(r / side) });
      if (b && LOGRE.test(b.typeId)) {
        const n = fellTree(dim, b);
        if (n > 0) { energy -= n * 100; cool = 4; break; }
      }
    }
    setP(e, "scan", (scan + 30) % total);
    energy -= def.rf * STEP * (cool > 0 ? 1 : 0.2);
    setP(e, "energy", Math.max(0, energy));
  }
  if (cool > 0) setP(e, "cool", cool - 1);
  setWorking(e, cool > 0);
}
// ---------------- Enderic Laser (igual ao Java: o Target Designator define o alvo; o feixe vai até 128 blocos) ----------------
// Receita "oritech:laser" do Java: amethyst_cluster -> 1 fluxite, que cai no inventário interno (3 slots; o excedente é destruído).
// Vidro, painéis de vidro e brotos de ametista deixam o feixe passar (tag laser_passthrough). Sem ataque a mobs (isso só existe com o Hunter Addon).
const LASER_SLOTS = [1, 2, 3], LASER_BREAK_BASE = 1024, LASER_CLUSTER = "minecraft:amethyst_cluster";
const GL_TITLE = "\u00a7r\u00a75\u00a7r", GZ_TITLE = "\u00a7r\u00a76\u00a7r";   // títulos invisíveis: ativam as telas customizadas (chest_screen)
const laserPass = (id) => id === "minecraft:glass" || id === "minecraft:tinted_glass" || id.endsWith("_stained_glass") || id === "minecraft:glass_pane" || id.endsWith("_stained_glass_pane") || id.endsWith("amethyst_bud");
function laserTarget(e) { return getP(e, "hasT") ? { x: getP(e, "tx"), y: getP(e, "ty"), z: getP(e, "tz") } : undefined; }
function laserInsert(c, id, n) {
  const max = new ItemStack(id, 1).maxAmount;
  for (const sl of LASER_SLOTS) { const it = c.getItem(sl); if (it && it.typeId === id && it.amount < max) { const q = Math.min(n, max - it.amount); it.amount += q; c.setItem(sl, it); n -= q; if (n <= 0) return 0; } }
  for (const sl of LASER_SLOTS) { if (!c.getItem(sl)) { const q = Math.min(n, max); c.setItem(sl, new ItemStack(id, q)); n -= q; if (n <= 0) return 0; } }
  return n;
}
// avança de 0,45 em 0,45 bloco a partir da cabeça (como o basicRaycast do Java) até o primeiro bloco que não deixa o feixe passar
function laserRay(dim, o, t, range, cells) {
  let dx = t.x + 0.5 - o.x, dy = t.y + 0.5 - o.y, dz = t.z + 0.5 - o.z;
  const len = Math.hypot(dx, dy, dz);
  if (len < 0.01) return undefined;
  dx /= len; dy /= len; dz /= len;
  let last = "";
  for (let d = 1.5; d <= range; d += 0.45) {
    const bx = Math.floor(o.x + dx * d), by = Math.floor(o.y + dy * d), bz = Math.floor(o.z + dz * d), key = `${bx},${by},${bz}`;
    if (key === last) continue;
    last = key;
    if (cells.some((c) => c.x === bx && c.y === by && c.z === bz)) continue;   // o corpo da própria torreta não bloqueia
    let b;
    try { b = dim.getBlock({ x: bx, y: by, z: bz }); } catch { return { end: d, o, dx, dy, dz }; }   // chunk descarregado
    if (!b) return { end: d, o, dx, dy, dz };
    if (b.isAir || b.isLiquid || laserPass(b.typeId)) continue;
    return { block: b, end: d, o, dx, dy, dz };
  }
  return { end: range, o, dx, dy, dz };
}
function guiLaserSync(e, def, state) {
  const c = guiContainer(e);
  if (!c) return;
  if (e.nameTag !== GZ_TITLE) e.nameTag = GZ_TITLE;
  const energy = getP(e, "energy");
  const msg = ["§7Sem alvo — use o Designador de Alvo", "§aDisparando", "§eSem cluster de ametista no caminho", "§cSem energia"][state] ?? "";
  guiPaintBar(c, 0, "energy", energy / def.cap, "§6Energia", [`§f${fmtRF(energy)} / ${fmtRF(def.cap)} RF`, msg]);
}
function tickLaser(m, def) {
  const { e, dim, base } = m;
  let energy = getP(e, "energy"), state = 0, hit = false;
  const t = laserTarget(e);
  if (t) {
    if (energy < def.rf * STEP) state = 3;
    else {
      const o = { x: base.x + 0.5, y: base.y + 1.5, z: base.z + 0.5 };
      const r = laserRay(dim, o, t, def.range, m.cells ?? cellsOf(e));
      if (r && r.block && r.block.typeId === LASER_CLUSTER) {
        hit = true; state = 1;
        const bp = r.block.location, key = `${bp.x},${bp.y},${bp.z}`;
        if (getP(e, "lkey", "") !== key) { setP(e, "lkey", key); setP(e, "lprog", 0); }
        energy -= def.rf * STEP;
        const need = LASER_BREAK_BASE * 1.5;                       // 1024 RF base (config do Java) x dureza do cluster (1,5)
        let prog = getP(e, "lprog") + def.rf * STEP;
        // feixe (partículas ao longo do caminho)
        try {
          const stp = Math.max(1.5, r.end / 24);
          for (let d = 1.5; d <= r.end; d += stp) dim.spawnParticle("minecraft:endrod", { x: r.o.x + r.dx * d, y: r.o.y + r.dy * d, z: r.o.z + r.dz * d });
        } catch (err) { /* alguns nomes de partículas variam entre versões */ }
        if (prog >= need) {
          prog = 0;
          const pos = { x: bp.x, y: bp.y, z: bp.z }, ctr = { x: bp.x + 0.5, y: bp.y + 0.5, z: bp.z + 0.5 };
          dim.setBlockType(pos, "minecraft:air");                   // sem os drops do cluster: o resultado vem da receita do laser
          const c = guiContainer(e);
          if (c) laserInsert(c, "oritech:fluxite", 1);
          try { dim.spawnParticle("minecraft:sonic_explosion", ctr); } catch (err) { /* ignora */ }
          dim.playSound("break.amethyst_cluster", ctr, { volume: 1 });
          setP(e, "lkey", "");
        }
        setP(e, "lprog", prog);
      } else state = 2;
    }
  }
  if (!hit && getP(e, "lprog") > 0) setP(e, "lprog", 0);
  setP(e, "energy", Math.max(0, energy));
  setWorking(e, hit);
  guiLaserSync(e, def, state);
}
function tickConsumer(m, def) {
  const energy = getP(m.e, "energy"), on = energy >= def.rf * STEP;
  if (on) setP(m.e, "energy", energy - def.rf * STEP);
  setWorking(m.e, on);
  if (on) machineFx(m);
}
const SPECIAL_TICK = { drill: tickDrill, cutter: tickCutter, laser: tickLaser, consumer: tickConsumer, acc_ctrl: (m) => accInject(m), acc_motor: () => {}, acc_sensor: () => {} };

// itens jogados em cima/ao lado da máquina são absorvidos
function absorbItems(m) {
  const { e, dim, base } = m, cells = m.cells ?? cellsOf(e);
  let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9, y0 = 1e9, y1 = -1e9;
  for (const c of cells) { x0 = Math.min(x0, c.x); x1 = Math.max(x1, c.x); z0 = Math.min(z0, c.z); z1 = Math.max(z1, c.z); y0 = Math.min(y0, c.y); y1 = Math.max(y1, c.y); }
  const hx = (x1 - x0 + 1) / 2, hz = (z1 - z0 + 1) / 2, center = { x: (x0 + x1) / 2 + 0.5, y: (y0 + y1) / 2 + 0.5, z: (z0 + z1) / 2 + 0.5 };
  for (const it of dim.getEntities({ type: "minecraft:item", location: center, maxDistance: Math.max(hx, hz) + (y1 - y0 + 1) + 2 })) {
    const p = it.location;
    if (Math.abs(p.x - center.x) > hx + 0.6 || Math.abs(p.z - center.z) > hz + 0.6 || p.y < y0 - 0.2 || p.y > y1 + 2.6) continue;
    if (p.z > z1 + 1.2) continue;      // não reabsorver a saída da própria máquina (lado sul)
    const st = it.getComponent("minecraft:item")?.itemStack;
    if (!st) continue;
    const r = tryInsert(e, st.typeId, st.amount);
    if (r.n <= 0) continue;
    const left = st.amount - r.n, loc = it.location;
    it.remove();
    if (left > 0) dim.spawnItem(new ItemStack(st.typeId, left), loc);
    if (r.ret) dim.spawnItem(new ItemStack(r.ret, r.n), loc);
    dim.playSound("random.click", e.location, { volume: 0.5 });
  }
}

let stepN = 0;
system.runInterval(() => {
  stepN++;
  const list = [];
  for (const dimId of ["overworld", "nether", "the_end"]) {
    const dim = world.getDimension(dimId);
    for (const e of dim.getEntities({ families: ["oritech_machine"] })) {
      const base = baseOf(e);
      const b = dim.getBlock(base);
      if (!b) continue;                                            // chunk descarregado
      if (!ctrlIds.has(b.typeId)) { dismantle(e, true); continue; } // bloco sumiu
      // trava posição e rotação: a máquina nunca se move nem gira sozinha
      const r = e.getRotation(), loc = e.location;
      if (Math.abs(loc.x - (base.x + 0.5)) > 0.05 || Math.abs(loc.y - base.y) > 0.05 || Math.abs(loc.z - (base.z + 0.5)) > 0.05 || Math.abs(r.y) > 0.5 || Math.abs(r.x) > 0.5)
        e.teleport({ x: base.x + 0.5, y: base.y, z: base.z + 0.5 }, { dimension: dim, rotation: { x: 0, y: 0 } });
      const id = idOf(e);
      let dep = getP(e, "deploy");
      if (dep > 0) {
        dep -= STEP; setP(e, "deploy", dep);
        if (dep <= 0) e.triggerEvent(getP(e, "open") ? "oritech:set_folded" : "oritech:set_idle");
        continue;
      }
      list.push({ e, dim, id, base, cells: cellsOf(e) });
    }
  }
  const seenRx = new Set();
  for (const dimId of ["overworld", "nether", "the_end"]) {
    const dim = world.getDimension(dimId);
    for (const e of dim.getEntities({ families: ["oritech_reactor"] })) {
      try {
        const r = rxLoad(e, dim);
        if (!r) continue;
        const cb = dim.getBlock(r.s.ctrl);
        if (!cb) continue;                                           // chunk descarregado
        seenRx.add(e.id);
        if (cb.typeId !== RX.ID.controller) { rxDismantle(r, true); continue; }
        list.push({ e, dim, id: "nuclear_reactor", base: r.s.ctrl, cells: r.s.ep });
      } catch (err) { console.warn("oritech reator:", err); }
    }
  }
  for (const id of [...RXR.keys()]) if (!seenRx.has(id)) RXR.delete(id);
  try { runNetworks(list); } catch (err) { console.warn("oritech rede:", err); }
  for (const m of list) {
    try {
      if (m.id === "nuclear_reactor") { tickReactor(m); continue; }
      const isMG = GEN[m.id] || MACH[m.id];
      if (isMG) absorbItems(m);
      if (isMG && stepN % 2 === 0) pullItems(m);
      if (GEN[m.id]) {
        if (GUI_GEN.has(m.id)) guiFeed(m.e, GEN[m.id]);
        if (GUI_STEAM.has(m.id)) guiSteamFeed(m.e, GEN[m.id]);
        tickGenerator(m, GEN[m.id]);
        if (GUI_GEN.has(m.id)) guiSync(m.e, GEN[m.id]);
        if (GUI_STEAM.has(m.id)) guiSteamSync(m.e, GEN[m.id]);
      }
      else if (MACH[m.id]) {
        if (GUI_MACH[m.id]) guiMachPre(m.e, MACH[m.id]);
        tickMachine(m, MACH[m.id]);
        if (GUI_MACH[m.id]) guiMachPost(m.e, MACH[m.id]);
      }
      else if (SPECIAL[m.id]) SPECIAL_TICK[SPECIAL[m.id].kind](m, SPECIAL[m.id]);
      else if (STORE[m.id]) { tickStore(m, STORE[m.id]); if (m.id === "large_storage") guiStoreSync(m.e, STORE[m.id]); }
    } catch (err) { console.warn(`oritech ${m.id}:`, err); }
  }
  // olhar para a máquina mostra o conteúdo, sem clicar
  for (const p of world.getAllPlayers()) {
    try {
      const b = p.getBlockFromViewDirection({ maxDistance: 6 })?.block;
      if (b && RX.isReactorBlock(b.typeId)) {
        const rr = rxAt(b.dimension, b.x, b.y, b.z);
        if (rr) p.onScreenDisplay.setActionBar(rxStatus(rr));
        else if (b.typeId === RX.ID.controller) p.onScreenDisplay.setActionBar(`§6${NAMES.nuclear_reactor}§r\n§7Não montado — clique no controlador para escanear a estrutura`);
        continue;
      }
      if (!b || !isMachineBlockId(b.typeId)) continue;
      if (ctrlIds.has(b.typeId) && b.permutation.getState("oritech:built") === false) {
        const bp = ctrlInfo(b); p.onScreenDisplay.setActionBar(`§bProjeto: ${NAMES[bp.id]} §7— faltam §e${missing(b.dimension, bp)} §7núcleos`); continue;
      }
      const e = machineAt(b.dimension, b.x, b.y, b.z);
      if (e) p.onScreenDisplay.setActionBar(status(e));
    } catch { /* ignora */ }
  }
}, STEP);
