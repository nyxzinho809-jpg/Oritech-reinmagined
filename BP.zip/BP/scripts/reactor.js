// Reator nuclear do Oritech (multibloco de tamanho variável) — lógica pura, sem API do Minecraft.
// Valores padrão tirados da configuração do mod original (OritechConfig) e da documentação do reator.

export const CFG = {
  RF_PER_PULSE: 64,          // rfPerPulse
  ABSORBER_RATE: 16,         // calor removido por vizinho, por tick (absorvedor com gelo)
  VENT_BASE: 4,              // ventBaseRate
  VENT_REL: 100,             // ventRelativeRate  -> remove calor/100 + 4
  MAX_HEAT: 2000,            // maxHeat (°C) para meltdown
  MAX_UNSTABLE_TICKS: 600,   // maxUnstableTicks
  WARN: 0.8,                 // alerta a 80% do calor máximo
  MAX_ENERGY: 50000000,      // reactorMaxEnergyStored
  PORT_OUT: 25000,           // reactorMaxEnergyOutput (RF/t por porta de energia)
  MAX_SIZE: 64,              // maxSize
  SAFE_MODE: false,          // true = entra em resfriamento em vez de explodir
  SAFE_COOLDOWN: 2400,       // safeModeCooldown (ticks)
  PORT_STOCK: 256,           // itens máximos guardados por porta
  COOLANT_UNITS: 200,        // ticks de resfriamento por gelo (por camada de absorvedor)
};

// capacidade (ticks de uma haste simples) de cada pelota — igual às receitas "oritech:reactor"
export const FUEL = { "oritech:uranium_pellet": 4000, "oritech:small_uranium_pellet": 400 };
export const COOLANT = { "minecraft:ice": CFG.COOLANT_UNITS, "minecraft:packed_ice": CFG.COOLANT_UNITS, "minecraft:blue_ice": CFG.COOLANT_UNITS };

export const ID = {
  wall: "oritech:reactor_wall", controller: "oritech:reactor_controller",
  rod: "oritech:reactor_rod", rod2: "oritech:reactor_double_rod", rod4: "oritech:reactor_quad_rod",
  pipe: "oritech:reactor_heat_pipe", vent: "oritech:reactor_vent", absorber: "oritech:reactor_condenser",
  reflector: "oritech:reactor_reflector", fuelPort: "oritech:reactor_fuel_port",
  coolPort: "oritech:reactor_absorber_port", energyPort: "oritech:reactor_energy_port",
};
export const ALL_IDS = new Set(Object.values(ID));
export const SHELL = new Set([ID.wall, ID.controller, ID.fuelPort, ID.coolPort, ID.energyPort]);
export const isReactorBlock = (t) => ALL_IDS.has(t);

// caractere de cada componente interno na grade
export const CHAR_OF = { [ID.rod]: "a", [ID.rod2]: "b", [ID.rod4]: "c", [ID.pipe]: "p", [ID.vent]: "v", [ID.absorber]: "o", [ID.reflector]: "f" };
const ROD_N = { a: 1, b: 2, c: 4 };           // quantidade de hastes (e pulsos enviados aos vizinhos)
const ROD_INT = { a: 1, b: 4, c: 12 };        // pulsos internos
const isRod = (c) => c === "a" || c === "b" || c === "c";
const holdsHeat = (c) => isRod(c) || c === "p";

const D6 = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];

// ---------------------------------------------------------------- varredura da estrutura
// getType(x,y,z) -> typeId | undefined (chunk descarregado). Gerador: faz "yield" de tempos em tempos
// e devolve { ok:true, s } ou { ok:false, err:{kind,...} }.
export function* scanGen(getType, ctrl, max = CFG.MAX_SIZE) {
  const key = (x, y, z) => `${x},${y},${z}`;
  const shell = new Map(), visited = new Set();
  const limit = 6 * max * max + 12 * max + 8;
  const stack = [[ctrl.x, ctrl.y, ctrl.z]];
  shell.set(key(ctrl.x, ctrl.y, ctrl.z), getType(ctrl.x, ctrl.y, ctrl.z));
  visited.add(key(ctrl.x, ctrl.y, ctrl.z));
  let steps = 0;
  while (stack.length) {
    const [x, y, z] = stack.pop();
    for (const [dx, dy, dz] of D6) {
      const nx = x + dx, ny = y + dy, nz = z + dz, k = key(nx, ny, nz);
      if (visited.has(k)) continue;
      visited.add(k);
      const t = getType(nx, ny, nz);
      if (t === undefined) return { ok: false, err: { kind: "unloaded" } };
      if (!SHELL.has(t)) continue;
      shell.set(k, t);
      if (shell.size > limit) return { ok: false, err: { kind: "big" } };
      stack.push([nx, ny, nz]);
    }
    if (++steps % 2500 === 0) yield;
  }
  let mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9];
  for (const k of shell.keys()) {
    const p = k.split(",").map(Number);
    for (let i = 0; i < 3; i++) { mn[i] = Math.min(mn[i], p[i]); mx[i] = Math.max(mx[i], p[i]); }
  }
  const dim = [mx[0] - mn[0] + 1, mx[1] - mn[1] + 1, mx[2] - mn[2] + 1];
  if (dim.some((d) => d < 3)) return { ok: false, err: { kind: "small", dim } };
  if (dim.some((d) => d > max)) return { ok: false, err: { kind: "size", dim, max } };

  // superfície: tudo precisa ser casca; arestas só de parede comum
  const ep = [], fpPos = [], cpPos = [];
  let controllers = 0;
  for (let x = mn[0]; x <= mx[0]; x++) for (let y = mn[1]; y <= mx[1]; y++) for (let z = mn[2]; z <= mx[2]; z++) {
    const ex = (x === mn[0] || x === mx[0]) ? 1 : 0, ey = (y === mn[1] || y === mx[1]) ? 1 : 0, ez = (z === mn[2] || z === mx[2]) ? 1 : 0;
    const ext = ex + ey + ez;
    if (ext === 0) continue;
    const t = shell.get(key(x, y, z));
    if (!t) return { ok: false, err: { kind: "gap", pos: [x, y, z] } };
    if (t === ID.controller) controllers++;
    if (ext >= 2 && t !== ID.wall) return { ok: false, err: { kind: "edge", pos: [x, y, z], type: t } };
    if (t === ID.energyPort) ep.push({ x, y, z });
    if (t === ID.fuelPort || t === ID.coolPort) {
      if (!(ey && y === mx[1])) return { ok: false, err: { kind: "badport", pos: [x, y, z] } };
      (t === ID.fuelPort ? fpPos : cpPos).push({ x, y, z });
    }
    if (++steps % 2500 === 0) yield;
  }
  if (controllers !== 1) return { ok: false, err: { kind: "controllers", n: controllers } };
  // casca fora da caixa (blocos de casca soltos dentro dela) é pega na leitura do interior
  const iw = dim[0] - 2, idp = dim[2] - 2, ih = dim[1] - 2;
  const grid = new Array(iw * idp).fill(".");
  for (let yy = 0; yy < ih; yy++) {
    for (let zz = 0; zz < idp; zz++) for (let xx = 0; xx < iw; xx++) {
      const x = mn[0] + 1 + xx, y = mn[1] + 1 + yy, z = mn[2] + 1 + zz;
      const t = getType(x, y, z);
      if (t === undefined) return { ok: false, err: { kind: "unloaded" } };
      let c;
      if (t === "minecraft:air") c = ".";
      else if (CHAR_OF[t]) c = CHAR_OF[t];
      else return { ok: false, err: { kind: "invalid", pos: [x, y, z], type: t } };
      const i = xx + zz * iw;
      if (yy === 0) grid[i] = c;
      else if (grid[i] !== c) return { ok: false, err: { kind: "layer", pos: [x, y, z] } };
      if (++steps % 2500 === 0) yield;
    }
  }
  const col = (p) => (p.x - mn[0] - 1) + (p.z - mn[2] - 1) * iw;
  const fp = [], cp = [];
  for (const p of fpPos) { const c = col(p); if (!isRod(grid[c])) return { ok: false, err: { kind: "portbelow", pos: [p.x, p.y, p.z], need: "haste" } }; fp.push(c); }
  for (const p of cpPos) { const c = col(p); if (grid[c] !== "o") return { ok: false, err: { kind: "portbelow", pos: [p.x, p.y, p.z], need: "absorvedor" } }; cp.push(c); }
  const rods = grid.filter(isRod).length;
  return { ok: true, s: { mn, mx, iw, id: idp, ih, grid: grid.join(""), fp, cp, ep, ctrl: { x: ctrl.x, y: ctrl.y, z: ctrl.z }, rods } };
}

export const colPos = (s, c) => ({ x: s.mn[0] + 1 + (c % s.iw), y: s.mx[1], z: s.mn[2] + 1 + Math.floor(c / s.iw) });
export const inBox = (s, x, y, z) => x >= s.mn[0] && x <= s.mx[0] && y >= s.mn[1] && y <= s.mx[1] && z >= s.mn[2] && z <= s.mx[2];

// ---------------------------------------------------------------- estado
export function newState(s) {
  const n = s.iw * s.id;
  return { heat: new Array(n).fill(0), fuel: new Array(n).fill(0), fuelCap: new Array(n).fill(0), cool: new Array(n).fill(0),
    fInv: new Map(), cInv: new Map(), unstable: 0, cooldown: 0 };
}
const invCount = (m, c) => { const o = m.get(c); return o ? Object.values(o).reduce((a, b) => a + b, 0) : 0; };

// estado <-> JSON esparso (cabe nas propriedades dinâmicas)
export function packState(st) {
  const sp = (a) => { const o = {}; a.forEach((v, i) => { if (v) o[i] = Math.round(v * 100) / 100; }); return o; };
  const inv = (m) => { const o = {}; m.forEach((v, c) => { if (Object.keys(v).length) o[c] = v; }); return o; };
  return JSON.stringify({ h: sp(st.heat), f: sp(st.fuel), fc: sp(st.fuelCap), c: sp(st.cool), fi: inv(st.fInv), ci: inv(st.cInv), u: st.unstable, cd: st.cooldown });
}
export function unpackState(s, txt) {
  const st = newState(s);
  try {
    const o = JSON.parse(txt), n = st.heat.length;
    const put = (a, src) => { for (const k of Object.keys(src ?? {})) if (+k < n) a[+k] = src[k]; };
    put(st.heat, o.h); put(st.fuel, o.f); put(st.fuelCap, o.fc); put(st.cool, o.c);
    for (const k of Object.keys(o.fi ?? {})) if (+k < n) st.fInv.set(+k, o.fi[k]);
    for (const k of Object.keys(o.ci ?? {})) if (+k < n) st.cInv.set(+k, o.ci[k]);
    st.unstable = o.u ?? 0; st.cooldown = o.cd ?? 0;
  } catch { /* estado vazio */ }
  return st;
}
// reaproveita o estado de uma estrutura antiga (mesmas coordenadas absolutas) ao reescanear
export function migrate(oldS, oldSt, newS) {
  const st = newState(newS);
  const idxOld = (x, z) => { const xx = x - oldS.mn[0] - 1, zz = z - oldS.mn[2] - 1; return xx >= 0 && zz >= 0 && xx < oldS.iw && zz < oldS.id ? xx + zz * oldS.iw : -1; };
  const lost = [];
  for (let i = 0; i < newS.iw * newS.id; i++) {
    const x = newS.mn[0] + 1 + (i % newS.iw), z = newS.mn[2] + 1 + Math.floor(i / newS.iw), j = idxOld(x, z);
    if (j < 0) continue;
    if (oldS.grid[j] === newS.grid[i]) { st.heat[i] = oldSt.heat[j]; st.fuel[i] = oldSt.fuel[j]; st.fuelCap[i] = oldSt.fuelCap[j]; st.cool[i] = oldSt.cool[j]; }
    if (newS.fp.includes(i) && oldSt.fInv.has(j)) st.fInv.set(i, oldSt.fInv.get(j));
    if (newS.cp.includes(i) && oldSt.cInv.has(j)) st.cInv.set(i, oldSt.cInv.get(j));
  }
  // itens de portas que deixaram de existir voltam como sobra
  oldSt.fInv.forEach((inv, j) => { const x = oldS.mn[0] + 1 + (j % oldS.iw), z = oldS.mn[2] + 1 + Math.floor(j / oldS.iw);
    const i = (x - newS.mn[0] - 1) + (z - newS.mn[2] - 1) * newS.iw;
    if (!(x > newS.mn[0] && x < newS.mx[0] && z > newS.mn[2] && z < newS.mx[2] && newS.fp.includes(i))) for (const [id, n] of Object.entries(inv)) lost.push([id, n]); });
  oldSt.cInv.forEach((inv, j) => { const x = oldS.mn[0] + 1 + (j % oldS.iw), z = oldS.mn[2] + 1 + Math.floor(j / oldS.iw);
    const i = (x - newS.mn[0] - 1) + (z - newS.mn[2] - 1) * newS.iw;
    if (!(x > newS.mn[0] && x < newS.mx[0] && z > newS.mn[2] && z < newS.mx[2] && newS.cp.includes(i))) for (const [id, n] of Object.entries(inv)) lost.push([id, n]); });
  st.unstable = oldSt.unstable; st.cooldown = oldSt.cooldown;
  return { st, lost };
}

// ---------------------------------------------------------------- inserir / retirar itens nas portas
function insertInto(map, table, ports, id, amount, col) {
  if (!table[id] || amount <= 0) return 0;
  const cols = col !== undefined && col >= 0 ? (ports.includes(col) ? [col] : []) : [...ports].sort((a, b) => invCount(map, a) - invCount(map, b));
  let left = amount;
  for (const c of cols) {
    const room = CFG.PORT_STOCK - invCount(map, c), n = Math.min(left, room);
    if (n <= 0) continue;
    const inv = map.get(c) ?? {}; inv[id] = (inv[id] ?? 0) + n; map.set(c, inv); left -= n;
    if (left <= 0) break;
  }
  return amount - left;
}
export const insertFuel = (s, st, id, n, col) => insertInto(st.fInv, FUEL, s.fp, id, n, col);
export const insertCoolant = (s, st, id, n, col) => insertInto(st.cInv, COOLANT, s.cp, id, n, col);
export const accepts = (id) => !!(FUEL[id] || COOLANT[id]);
// esvazia uma porta (ou todas) devolvendo [[id,n],...]
export function takeItems(st, col) {
  const out = [];
  for (const m of [st.fInv, st.cInv]) {
    const cols = col === undefined ? [...m.keys()] : [col];
    for (const c of cols) { const inv = m.get(c); if (!inv) continue; for (const [id, n] of Object.entries(inv)) if (n > 0) out.push([id, n]); m.delete(c); }
  }
  return out;
}

function takeUnit(inv, table) {
  if (!inv) return 0;
  const ids = Object.keys(inv).filter((i) => inv[i] > 0).sort((a, b) => table[b] - table[a]);
  if (!ids.length) return 0;
  inv[ids[0]]--; if (inv[ids[0]] <= 0) delete inv[ids[0]];
  return table[ids[0]];
}

// ---------------------------------------------------------------- simulação (dt ticks por chamada)
// Retorna { gen, active, hotRod, hotAny, warn, melt, safeStop }
export function step(s, st, dt, disabled = false) {
  const n = s.iw * s.id, g = s.grid, h = s.ih, W = s.iw, D = s.id;
  const out = { gen: 0, active: 0, hotRod: 0, hotAny: 0, warn: false, melt: false, safeStop: false, lit: new Array(n).fill(false) };
  if (st.cooldown > 0) { st.cooldown = Math.max(0, st.cooldown - dt); disabled = true; }
  const nb = (i) => {
    const x = i % W, z = (i / W) | 0, r = [];
    if (x > 0) r.push(i - 1); if (x < W - 1) r.push(i + 1); if (z > 0) r.push(i - W); if (z < D - 1) r.push(i + W);
    return r;
  };
  // 1) combustível: cada haste queima (hastes × altura) unidades por tick
  const act = new Array(n).fill(0);
  for (let i = 0; i < n; i++) {
    if (!isRod(g[i]) || disabled) continue;
    const need = ROD_N[g[i]] * h * dt;
    let remaining = need, burned = 0, guard = 0;
    while (remaining > 1e-9 && guard++ < 8) {
      if (st.fuel[i] <= 1e-9) {
        const cap = s.fp.includes(i) ? takeUnit(st.fInv.get(i), FUEL) : 0;
        if (cap <= 0) break;
        st.fuel[i] += cap; st.fuelCap[i] = cap;
      }
      const u = Math.min(st.fuel[i], remaining);
      st.fuel[i] -= u; remaining -= u; burned += u;
    }
    act[i] = burned / need;
  }
  // 2) pulsos -> calor e energia
  for (let i = 0; i < n; i++) {
    if (act[i] <= 0) continue;
    let ext = 0;
    for (const j of nb(i)) {
      if (isRod(g[j]) && act[j] > 0) ext += ROD_N[g[j]];
      else if (g[j] === "f") ext += ROD_N[g[i]];
    }
    const total = ROD_INT[g[i]] + ext;
    st.heat[i] += Math.floor((total / 2) * total + 4) * dt * act[i];
    out.gen += total * CFG.RF_PER_PULSE / 2 * h * dt * act[i];
    out.active++; out.lit[i] = true;
  }
  // 3) tubos de calor: puxam calor dos vizinhos mais quentes (hastes/tubos)
  const delta = new Array(n).fill(0);
  for (let i = 0; i < n; i++) {
    if (g[i] !== "p") continue;
    for (const j of nb(i)) {
      if (!holdsHeat(g[j])) continue;
      const diff = st.heat[j] - st.heat[i];
      if (diff <= 0) continue;
      const f = Math.min((diff / 4 + 10) * dt, diff / 2);
      delta[j] -= f; delta[i] += f;
    }
  }
  for (let i = 0; i < n; i++) st.heat[i] = Math.max(0, st.heat[i] + delta[i]);
  // 4) ventiladores: tiram calor do vizinho mais quente
  for (let i = 0; i < n; i++) {
    if (g[i] !== "v") continue;
    let best = -1;
    for (const j of nb(i)) if (holdsHeat(g[j]) && (best < 0 || st.heat[j] > st.heat[best])) best = j;
    if (best < 0 || st.heat[best] <= 0) continue;
    st.heat[best] = Math.max(0, st.heat[best] - Math.min(st.heat[best], (st.heat[best] / CFG.VENT_REL + CFG.VENT_BASE) * dt));
  }
  // 5) absorvedores: 16 de calor por vizinho por tick, consumindo gelo da porta acima
  for (let i = 0; i < n; i++) {
    if (g[i] !== "o") continue;
    const need = h * dt;
    let remaining = need, burned = 0, guard = 0;
    while (remaining > 1e-9 && guard++ < 8) {
      if (st.cool[i] <= 1e-9) {
        const cap = s.cp.includes(i) ? takeUnit(st.cInv.get(i), COOLANT) : 0;
        if (cap <= 0) break;
        st.cool[i] += cap;
      }
      const u = Math.min(st.cool[i], remaining);
      st.cool[i] -= u; remaining -= u; burned += u;
    }
    const eff = burned / need;
    if (eff <= 0) continue;
    for (const j of nb(i)) if (holdsHeat(g[j])) st.heat[j] = Math.max(0, st.heat[j] - CFG.ABSORBER_RATE * dt * eff);
  }
  // 6) temperatura, alarme e meltdown
  for (let i = 0; i < n; i++) {
    if (isRod(g[i])) out.hotRod = Math.max(out.hotRod, st.heat[i]);
    if (holdsHeat(g[i])) out.hotAny = Math.max(out.hotAny, st.heat[i]);
  }
  out.warn = out.hotAny >= CFG.WARN * CFG.MAX_HEAT;
  if (out.hotRod > CFG.MAX_HEAT) st.unstable += dt; else st.unstable = Math.max(0, st.unstable - dt);
  if (st.unstable >= CFG.MAX_UNSTABLE_TICKS) {
    if (CFG.SAFE_MODE) { st.cooldown = CFG.SAFE_COOLDOWN; st.unstable = 0; out.safeStop = true; }
    else out.melt = true;
  }
  return out;
}

// ---------------------------------------------------------------- resumo para a tela de status
export function summary(s, st) {
  const n = s.iw * s.id, g = s.grid, h = s.ih;
  let hot = 0, rodsOn = 0, fuelSec = Infinity, coolSec = Infinity, pellets = 0, ice = 0, hasFuelPort = false, hasCoolPort = false, fuelUnits = 0;
  for (let i = 0; i < n; i++) {
    if (holdsHeat(g[i])) hot = Math.max(hot, st.heat[i]);
    if (isRod(g[i]) && st.fuel[i] > 0) rodsOn++;
  }
  for (const c of s.fp) {
    hasFuelPort = true;
    let units = st.fuel[c]; const inv = st.fInv.get(c) ?? {};
    for (const [id, k] of Object.entries(inv)) { units += k * FUEL[id]; pellets += k; }
    fuelUnits += units;
    fuelSec = Math.min(fuelSec, units / (ROD_N[g[c]] * h) / 20);
  }
  for (const c of s.cp) {
    hasCoolPort = true;
    let units = st.cool[c]; const inv = st.cInv.get(c) ?? {};
    for (const [id, k] of Object.entries(inv)) { units += k * COOLANT[id]; ice += k; }
    coolSec = Math.min(coolSec, units / h / 20);
  }
  const fuelMax = s.fp.length * CFG.PORT_STOCK * FUEL["oritech:uranium_pellet"];   // capacidade total de combustível (para a barra verde)
  return { hot, rodsOn, rodsTotal: s.rods, fuelUnits, fuelMax, fuelSec: hasFuelPort ? fuelSec : 0, coolSec: hasCoolPort ? coolSec : 0, pellets, ice, hasFuelPort, hasCoolPort,
    cooldown: st.cooldown, unstable: st.unstable };
}
// potência do meltdown (hastes × altura) para dimensionar a explosão
export const meltPower = (s) => s.grid.split("").reduce((a, c) => a + (isRod(c) ? ROD_N[c] : 0), 0) * s.ih;
